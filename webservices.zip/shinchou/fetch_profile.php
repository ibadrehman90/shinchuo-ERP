<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_GET['userid'];



$sql = "SELECT * from auth where userid = '{$userid}'";

$result = $conn->query($sql);
$response["Status"] = "null";

$i = 0;

 while($row = $result->fetch_assoc()) {
     
     

    $arr[$i]["email"] = $row["email"];
	$arr[$i]["fname"] = $row["fname"];
	$arr[$i]["lname"] = $row["lname"];
	$arr[$i]["country"] = $row["country"];
	$arr[$i]["city"] = $row["city"];
	$arr[$i]["company"] = $row["company"];
	$arr[$i]["phone"] = $row["phone"];

     		
$i++; 
}

$conn->close();	
$response['Status'] = $arr;
echo json_encode($response);
	 
	
?>