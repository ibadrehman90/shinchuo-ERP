<?php
header("Content-Type: application/json");

require('db_con.php');

$pid = $_POST['pid'];
$lot = $_POST['lot'];
$make = $_POST['make'];
$model = $_POST['model'];
$price = $_POST['price'];
$auction = $_POST['auction'];
$auctiondate = $_POST['auctiondate'];
$mileage = $_POST['mileage'];
$year = $_POST['year'];
$img_url = $_POST['img_url'];
$userid = $_POST['userid'];
$wishlist = $_POST['wishlist'];

$sql = "SELECT * from wishlist where userid = '{$userid}' AND p_id = '{$pid}'";

$result = $conn->query($sql);

$cid = 0;

 while($row = $result->fetch_assoc()) {	
	
	$cid = $row['lot'];		   
 }
 
 if($cid == 0)
 {
	$sql = "insert into wishlist(p_id,lot,make,model,price,auction,auctiondate,mileage,year,img_url,userid,wishlist) values('{$pid}','{$lot}','{$make}','{$model}','{$price}','{$auction}','{$auctiondate}','{$mileage}','{$year}','{$img_url}','{$userid}','{$wishlist}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 
 }
 else
 {
	$sql = "update wishlist set wishlist = '{$wishlist}' where userid = '{$userid}' AND p_id = '{$pid}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}
 }

$conn->close();  
	
echo json_encode($response);
	 
	
?>