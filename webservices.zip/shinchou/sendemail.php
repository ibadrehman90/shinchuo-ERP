<?php
header("Content-Type: application/json");

require('db_con.php');

$str = $_POST["str"];
$email = $_POST["email"];

$str_1 = "[".substr($str,0,strlen($str) - 1)."]";
$res = json_decode($str_1, true);

$sfr = '';
$arr = array();

$sfr = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>Email Format</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  
 <style>
 h3{
 margin:5px;
 padding:10px;
 font-family: Calibri;
 }
 
 span
 {
	font-size:14px;
	color:#333;
 }
 </style>
  
 </head>
<body style="margin: 0; padding: 0;">
 <table align="center" cellpadding="0" cellspacing="0" style="border-collapse: collapse;">
 
 <tr style="border-bottom:1px solid #999;text-align:center">
  <td colspan="2"><h3>SHINCHOU CARS PURCHASED LIST</h3></td>
 </tr>
';

for($i = 0; $i < count($res); $i++)
{
	$sql = "SELECT *,(select images from productdetail where id = purchasedlist.prodid) as images from purchasedlist where s_id = '{$res[$i]["prodid"]}'";

	$result = $conn->query($sql);

	while($row = $result->fetch_assoc()) { 
		$arr[$i]["images"] = $row["images"];       	
		$arr[$i]["client"] = $row["client"];
		$arr[$i]["auction"] = $row["auction"];
		$arr[$i]["adate"] = $row["adate"];
		$arr[$i]["lot"] = $row["lot"];
		$arr[$i]["prefix"] = $row["prefix"];
		$arr[$i]["make"] = $row["make"];
		$arr[$i]["model"] = $row["model"];
		$arr[$i]["year"] = $row["year"];
		$arr[$i]["bidprice"] = $row["bidprice"];
		$arr[$i]["transmission"] = $row["transmission"];
		$arr[$i]["enginecc"] = $row["enginecc"];
		$arr[$i]["mileage"] = $row["mileage"];
		$arr[$i]["color"] = $row["color"];
	}
	
	$imgsplit = explode("#",$res[$i]["imges"]);
	
	$sfr .='
<tr>
	<td style="width:25%; padding:10px;text-align:justify; border-right:1px solid #999;border-bottom:1px solid #999">
		<p>
		<b>' . $arr[$i]["year"] . ' ' . $arr[$i]["make"] . ' ' . $arr[$i]["model"] . '</b>
		<br/>
		Purchased Amount: ¥ '  . $arr[$i]["bidprice"] . ' '  . $arr[$i]["auction"] . ' '  . $arr[$i]["mileage"] . 'km '  . $arr[$i]["enginecc"] . 'cc '  . $arr[$i]["lot"] . ' '  . $arr[$i]["prefix"] . ' '  . $arr[$i]["transmission"] . '
		</p>
	</td>
	<td style="width:75%;border-bottom:1px solid #999">
		<table>
			<tr>';
			
		for($f = 0; $f < sizeof($imgsplit); $f++)
		{
			$sfr .= '<td style="25%"><img src="' . $imgsplit[$f] .'" height="100"/></td>';
			
			if($f == 4 || $f == 8)
			{
				$sfr .= '</tr><tr>';
			}			
		}

$sfr .='</tr></table>
	</td>
</tr>';
	
}

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

 
$sfr.= '
</table>
</body>
</html>';

$conn->close();	
$response['Status'] = '';
 	
if(mail($email,"Shinchou Cars Purchased List",$sfr, $headers))
{
$response['Status'] = 'Done';
}
else
{
$response['Status'] = 'An Error Occured. Please try again later!';
}




 	 echo json_encode($response);
	 
	
?>