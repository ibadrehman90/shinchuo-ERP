<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_GET['userid'];
$wishlist = "B";


$sql = "SELECT * from wishlist where userid = '{$userid}' AND wishlist = '{$wishlist}'";

$result = $conn->query($sql);
$response["Status"] = "null";

$i = 0;

 while($row = $result->fetch_assoc()) {
     
     

    $arr[$i]["prodid"] = $row["p_id"];
	$arr[$i]["lot"] = $row["lot"];
	$arr[$i]["make"] = $row["make"];
	$arr[$i]["model"] = $row["model"];
	$arr[$i]["startPrice"] = $row["price"];
	$arr[$i]["auctionVenue"] = $row["auction"];
	$arr[$i]["auctiondate"] = $row["auctiondate"];
	$arr[$i]["mileage"] = $row["mileage"];
	$arr[$i]["year"] = $row["year"];
	$arr[$i]["img"] = $row["img_url"];
 
     		
$i++; 
}

$conn->close();	
$response['Status'] = $arr;
echo json_encode($response);
	 
	
?>