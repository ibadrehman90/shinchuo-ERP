<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_GET['userid'];


$sql = "SELECT * from userauth where username = '{$userid}'";

$result = $conn->query($sql);
$response["Status"] = "null";

$i = 0;

 while($row = $result->fetch_assoc()) {
     
     

    $arr[$i]["fname"] = $row["name"];
	$arr[$i]["email"] = $row["email"];
	$arr[$i]["country"] = $row["country"];
	$arr[$i]["address"] = $row["address"];
	$arr[$i]["port"] = $row["port"];
	$arr[$i]["status"] = $row["status"];
	$arr[$i]["city"] = $row["city"];
	$arr[$i]["company"] = $row["company"];
	$arr[$i]["phone"] = $row["mobile"];
   
     		
$i++; 
}

$conn->close();	
$response['Status'] = $arr;
echo json_encode($response);
	 
	
?>