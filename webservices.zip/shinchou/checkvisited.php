<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_GET['userid'];
$prodid = $_GET['prodid'];

$sql = "SELECT * from visited where userid = '{$userid}' AND prodid = '{$prodid}'";

$result = $conn->query($sql);

$response["visited"] = "null";

 while($row = $result->fetch_assoc()) {
        		
	$response["visited"] = $row["prodid"];	
}

$conn->close();	

echo json_encode($response);
	 
	
?>