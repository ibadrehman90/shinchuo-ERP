<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_GET['userid'];
$wishlist = "A";


$sql = "SELECT * FROM productdetail t1 JOIN wishlist t2 ON t1.id = t2.p_id WHERE userid = '{$userid}'";

$result = $conn->query($sql);
$response["Status"] = "null";

$i = 0;

 while($row = $result->fetch_assoc()) {
     
     

    $arr[$i]["prodid"] = $row["p_id"];
	$arr[$i]["lot"] = $row["lot"];
	$arr[$i]["make"] = $row["make"];
	$arr[$i]["model"] = $row["model"];
	$arr[$i]["startPrice"] = $row["start"];
	$arr[$i]["auctionVenue"] = $row["auction"];
	$arr[$i]["auctiondate"] = $row["auction_date"];
	$arr[$i]["mileage"] = $row["mileage"];
	$arr[$i]["year"] = $row["year"];
	$arr[$i]["img"] = $row["images"];
 
     		
$i++; 
}

$conn->close();	
$response['Status'] = $arr;
echo json_encode($response);
	 
	
?>