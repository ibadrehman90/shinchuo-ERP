<?php
header("Content-Type: application/json");

require('db_con.php');

$prodid = $_GET['prodid'];
$userid = $_GET['userid'];


	$sql = "insert into visited(prodid,userid) values('{$prodid}','{$userid}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 
 

    $conn->close();  
	
echo json_encode($response);
	 
	
?>