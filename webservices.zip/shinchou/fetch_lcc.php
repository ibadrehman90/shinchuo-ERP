<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_GET['userid'];


$sql = "SELECT * from lccrequests where client = '{$userid}'";

$result = $conn->query($sql);
$response["Status"] = "null";

$i = 0;

 while($row = $result->fetch_assoc()) {
     
     

    $arr[$i]["sno"] = $row["sno"];
	$arr[$i]["requestby"] = $row["requestby"];
	$arr[$i]["agentfee"] = $row["agentfee"];
	$arr[$i]["gst"] = $row["exchange"];
	$arr[$i]["freight"] = $row["frieght"];
	$arr[$i]["adminstatus"] = $row["adminstatus"];

   
     		
$i++; 
}

$conn->close();	
$response['Status'] = $arr;
echo json_encode($response);
	 
	
?>