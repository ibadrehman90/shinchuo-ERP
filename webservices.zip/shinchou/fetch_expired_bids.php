<?php
header("Content-Type: application/json");

require('db_con.php');

date_default_timezone_set("Asia/Tokyo");

$userid = $_GET['userid'];
$today = date("Y-m-d H:i:s");

$sql = "SELECT * FROM productdetail t1 JOIN bids t2 ON t1.id = t2.prodid WHERE t2.user_id = '{$userid}' AND auction_date < '". date("Y-m-d") . "'";

$result = $conn->query($sql);
$response["Status"] = "null";

$i = 0;

 while($row = $result->fetch_assoc()) {
     
     
    $arr[$i]["prodid"] = $row["prodid"];
	$arr[$i]["lot"] = $row["lot"];
	$arr[$i]["make"] = $row["make"];
	$arr[$i]["model"] = $row["model"];
	$arr[$i]["startPrice"] = $row["start"];
	$arr[$i]["auctionVenue"] = $row["auction"];
	$arr[$i]["auctiondate"] = $row["auction_date"];
	$arr[$i]["mileage"] = $row["mileage"];
	$arr[$i]["year"] = $row["year"];
	$arr[$i]["img"] = $row["images"];
	$arr[$i]["bidPrice"] = $row["estprice"];
	$arr[$i]["bidDate"] = $row["datetme"];
	$arr[$i]["bidMsg"] = $row["bidmsg"];    
     		
$i++; 
}

$conn->close();	
$response['Status'] = $arr;
echo json_encode($response);
	 
	
?>