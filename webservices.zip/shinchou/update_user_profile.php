<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_GET['userid'];
$fname = $_GET['fname'];
$country= $_GET['country'];
$city= $_GET['city'];
$phone= $_GET['phone'];
$address= $_GET['address'];
$port= $_GET['port'];



$sql = "update userauth set name = '{$fname}',country= '{$country}',city = '{$city }',mobile = '{$phone}',address = '{$address}',port = '{$port}' where username = '{$userid}'";

$result = $conn->query($sql);


	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

$conn->close();	

echo json_encode($response);
	 
	
?>