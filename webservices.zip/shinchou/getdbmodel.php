<?php
header("Content-Type: application/json");

require('db_con.php');

$str = $_POST['str'];
$userid = $_POST['userid'];

$sql = "SELECT * from userauth inner join custommodel on userauth.country = custommodel.country where username = '{$userid}' AND (" . substr($str,0,-4) . ")";

$result = $conn->query($sql);

$i = 0;

$response["modellist"] = '';
$response["otherlist"] = '';

while($row = $result->fetch_assoc()) {
   
   $response["modellist"] .= substr($row['modellist'],1,-1) . ",";
   $response["otherlist"] .= substr($row['otherlist'],1,-1) . ",";
}

$response["modellist"] = "[" . substr($response['modellist'],0,-1) . "]";
$response["otherlist"] = "[" . substr($response['otherlist'],0,-1) . "]";

$conn->close();	

echo json_encode($response);
	 
	
?>