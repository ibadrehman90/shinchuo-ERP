<?php
header("Content-Type: application/json");

require('db_con.php');

$email = $_POST['email'];
$username = $_POST['username'];
$bname = $_POST['name'];
$pass = $_POST['password'];
$country = $_POST['country'];
$city = $_POST['city'];
$company = $_POST['company'];
$mob = $_POST['phone'];
$address = $_POST['address'];
$port = $_POST['port'];
$dor = date("Y-m-d");

$sql = "select email from userauth where email = '{$email}'";

$result = $conn->query($sql);

$i = 0;

while($row = $result->fetch_assoc()) {
 	$i++;     	
}

if($i == 0)
{
 	    
		$sql = "insert into userauth(username,email,password,name,city,country,mobile,port,dor,company,address,calculator,currency,showlcc,role,salesuser,status) values('{$username}','{$email}','{$pass}','{$bname}','{$city}','{$country}','{$mob}','{$port}','{$dor}','{$company}','{$address}','Default','JPY','1','client','','1'); insert into userview values('{$username}',1,1,1,1,1,1,1,1,1,1,1,1,1,1,1)";
		
		if($country == 'New Zealand')
		{
		    $sql = "insert into userauth(username,email,password,name,city,country,mobile,port,dor,company,address,calculator,currency,showlcc,role,salesuser,status) values('{$username}','{$email}','{$pass}','{$bname}','{$city}','{$country}','{$mob}','{$port}',,'{$dor}','{$company}','{$address}','Default','JPY','1','salesuser','NEW COW','1');";
		}

			if ($conn->multi_query($sql) === TRUE) {
				$response['Status'] = "Done";
			} else {
				$response['Status'] = "Error: " . $conn->error;
				
				if (strpos($response['Status'], 'PRIMARY') !== false) {
					$response['Status'] = 'UserExist';
				}
			}
}

else
{
	$response['Status'] = "Exist";
}

$conn->close();   
	

echo json_encode($response);
	 
	
?>