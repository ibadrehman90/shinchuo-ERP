<?php
header("Content-Type: application/json");

require('db_con.php');

$email = $_GET['email'];
$password = $_GET['password'];
$response['Status'] = "null";
$sql = "SELECT * from auth where email = '". $email . "'";

$result = $conn->query($sql);

 while($row = $result->fetch_assoc()) {
        		
		if($row['password'] == $password)
		{
			$response['Status'] = "Auth";
			$response['userid']	= $email;
			$response['approval']	= $row['approval'];
		}
		else
		{
			$response['Status'] = "No";
		}
}

$conn->close();	

echo json_encode($response);
	 
	
?>