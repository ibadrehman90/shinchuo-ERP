<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_GET['userid'];
$status = "3";


$sql = "SELECT * FROM productdetail t1 JOIN purchasedlist t2 ON t1.id = t2.prodid WHERE client = '{$userid}'";

$result = $conn->query($sql);
$response["Status"] = "null";

$i = 0;

 while($row = $result->fetch_assoc()) {
     
     

    $arr[$i]["model"] = $row["model"];
	$arr[$i]["make"] = $row["make"];
	$arr[$i]["lot"] = $row["lot"];
	$arr[$i]["startprice"] = $row["start"];
	$arr[$i]["bidamt"] = $row["bidprice"];
	$arr[$i]["img"] = $row["images"];
	$arr[$i]["year"] = $row["year"];

   
     		
$i++; 
}

$conn->close();	
$response['Status'] = $arr;
echo json_encode($response);
	 
	
?>