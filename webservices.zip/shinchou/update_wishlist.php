<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_GET['userid'];
$wishlist = $_GET['wishlist'];
$pid = $_GET['pid'];


$sql = "update wishlist set wishlist = '{$wishlist}' where userid = '{$userid}' AND p_id = '{$pid}'";

$result = $conn->query($sql);



if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 

$conn->close();	
$response['Status'] = $arr;
echo json_encode($response);
	 
	
?>