<?php
header("Content-Type: application/json");

require('db_con.php');

$salesuser = $_POST['username'];

$sql = "SELECT *,(select images from productdetail where id = purchasedlist.prodid) as pimages,(select newurl from productimages_temp where prodid = purchasedlist.prodid) as newimages,(select sheeturl from productimages_temp where prodid = purchasedlist.prodid) as newsheet from purchasedlist where client = '{$salesuser}' AND stocksold = 0";	

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["s_id"] = $row["s_id"]; 
$arr[$i]["prodid"] = $row["prodid"];
$arr[$i]["images"] = $row["pimages"];     
$arr[$i]["newimages"] = $row["newimages"];
$arr[$i]["newsheet"] = $row["newsheet"];
$arr[$i]["cimages"] = $row["images"];
$arr[$i]["s_code"] = $row["s_code"];
$arr[$i]["client"] = $row["client"];
$arr[$i]["dst"] = $row["dst"];
$arr[$i]["auction"] = $row["auction"];
$arr[$i]["adate"] = $row["adate"];
$arr[$i]["pos"] = $row["pos"];
$arr[$i]["dai"] = $row["dai"];
$arr[$i]["lot"] = $row["lot"];
$arr[$i]["prefix"] = $row["prefix"];
$arr[$i]["serial"] = $row["serial"];
$arr[$i]["make"] = $row["make"];
$arr[$i]["model"] = $row["model"];
$arr[$i]["year"] = $row["year"];
$arr[$i]["bidprice"] = $row["bidprice"];
$arr[$i]["aucfee"] = $row["aucfee"];
$arr[$i]["exportcharge"] = $row["exportcharge"];
$arr[$i]["noplate"] = $row["noplate"];
$arr[$i]["plateserial"] = $row["plateserial"];
$arr[$i]["shaken"] = $row["shaken"];
$arr[$i]["fudosha"] = $row["fudosha"];
$arr[$i]["transmission"] = $row["transmission"];
$arr[$i]["enginecc"] = $row["enginecc"];
$arr[$i]["mileage"] = $row["mileage"];
$arr[$i]["color"] = $row["color"];
$arr[$i]["colorcode"] = $row["colorcode"];
$arr[$i]["buyingcom"] = $row["buyingcom"];
$arr[$i]["buyer"] = $row["buyer"];
$arr[$i]["remark"] = $row["remark"];
$arr[$i]["landedvalue"] = $row["landedvalue"];
$arr[$i]["soldprice"] = $row["soldprice"];
$arr[$i]["status"] = $row["status"];
$arr[$i]["stocksold"] = $row["stocksold"];
$arr[$i]["sellingprice"] = $row["sellingprice"];
$arr[$i]["showsellprice"] = $row["showsellprice"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>