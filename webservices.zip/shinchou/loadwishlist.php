<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_POST['userid'];
$lot = $_POST['lot'];

$sql = "SELECT * from wishlist where userid = '{$userid}' AND p_id = '{$lot}'";

$result = $conn->query($sql);

$response["wishlist"] = "null";

 while($row = $result->fetch_assoc()) {
        		
	$response["wishlist"] = $row["wishlist"];
	
}

$conn->close();	

echo json_encode($response);
	 
	
?>