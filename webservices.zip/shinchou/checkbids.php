<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_GET['userid'];
$prodid = $_GET['prodid'];

$sql = "SELECT * from bids where user_id = '{$userid}' AND prodid = '{$prodid}'";

$result = $conn->query($sql);

$response["Status"] = "null";

 while($row = $result->fetch_assoc()) {
        		
	$response["Status"] = $row["estprice"];
	
}

$conn->close();	

echo json_encode($response);
	 
	
?>