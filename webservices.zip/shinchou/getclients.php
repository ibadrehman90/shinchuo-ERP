<?php
header("Content-Type: application/json");

require('db_con.php');

$salesuser = $_POST['client'];
$prodid = $_POST['prodid'];

$sql = "SELECT username, email from userauth where role = 'client' AND salesuser = '{$salesuser}' AND status = 1 AND username NOT IN (SELECT user_id from bids where prodid = '{$prodid}')";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["username"] = $row["username"];       	
$arr[$i]["email"] = $row["email"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>