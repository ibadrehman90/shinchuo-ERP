<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_POST['username'];

$sql = "SELECT salesuser from userauth where username = '{$userid}'";

$result = $conn->query($sql);

 while($row = $result->fetch_assoc()) {
        		
	$response["salesuser"] = $row["salesuser"];
	
}

$conn->close();	

echo json_encode($response);
	 
	
?>