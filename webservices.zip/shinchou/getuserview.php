<?php
header("Content-Type: application/json");

require('db_con.php');

$client = $_POST["client"];

$sql = "SELECT client,lot,auction,auctiondate,grade,equipment,chassis,enginecc,mileage,color,startprice,avgprice,soldprice,sheet,sheetdetail,showlcc,currency FROM `userview` inner join userauth on userview.client = userauth.username where client = '{$client}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
       	
$arr[$i]["client"] = $row["client"];
$arr[$i]["lot"] = $row["lot"];
$arr[$i]["auction"] = $row["auction"];
$arr[$i]["auctiondate"] = $row["auctiondate"];
$arr[$i]["grade"] = $row["grade"];
$arr[$i]["equipment"] = $row["equipment"];
$arr[$i]["chassis"] = $row["chassis"];
$arr[$i]["mileage"] = $row["mileage"];
$arr[$i]["color"] = $row["color"];
$arr[$i]["startprice"] = $row["startprice"];
$arr[$i]["avgprice"] = $row["avgprice"];
$arr[$i]["showlcc"] = $row["showlcc"];
$arr[$i]["soldprice"] = $row["soldprice"];
$arr[$i]["enginecc"] = $row["enginecc"];
$arr[$i]["sheet"] = $row["sheet"];
$arr[$i]["sheetdetail"] = $row["sheetdetail"];
$arr[$i]["sheetdetail"] = $row["sheetdetail"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>