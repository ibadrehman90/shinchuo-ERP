<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_POST['userid'];

$sql = "SELECT * from userauth inner join custommake on userauth.country = custommake.country where username = '{$userid}'";

$result = $conn->query($sql);

$response["makelist"] = "";
$response["otherlist"] = "";
 while($row = $result->fetch_assoc()) {
        		
	$response["makelist"] = $row["makelist"];
	$response["otherlist"] = $row["otherlist"];
	
}

$conn->close();	

echo json_encode($response);
	 
	
?>