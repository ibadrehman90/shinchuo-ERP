<?php
header("Content-Type: application/json");
ini_set("allow_url_fopen", 1);
require('db_con.php');

$pid = $_POST['pid'];
$userid = $_POST['userid'];
$wishlist = $_POST['wishlist'];

$sql = "SELECT * from wishlist where userid = '{$userid}' AND p_id = '{$pid}'";

$result = $conn->query($sql);

$cid = false;

 while($row = $result->fetch_assoc()) {	
	
	$cid = true;		   
 }
 
 if($cid == false)
 {
	 
	$subsql = "SELECT lot from productdetail where id = '{$pid}'";

	$subresult = $conn->query($subsql);

	$cond = false;

	while($row = $subresult->fetch_assoc()) {			
		$cond = true;		   
	}
	 
	if($cond === false)
	{
		$json = file_get_contents('http://75.125.226.218/xml/json?code=Vdf3_ryhAjmf7&sql=select%20*%20from%20main%20where%20id%20=%20%27'. $pid .'%27');
		$json = substr($json,1);
		$json = substr($json,0,strlen($json) - 1);
		$obj = json_decode($json);
		$imgs = $obj->IMAGES;

		$imgsplit = explode("#",$imgs);
		$newimgurl = '';
		for($i = 0; $i < sizeof($imgsplit); $i++)
		{
			$url = $imgsplit[$i];
			$img = 'uploads/' . 'img' . $i . $obj->ID . '.jpg';
			$newimgurl .= "http://".$_SERVER["HTTP_HOST"].substr($_SERVER["REQUEST_URI"],0,strrpos($_SERVER["REQUEST_URI"], "/") + 1) . $img."#";
			file_put_contents($img, file_get_contents($url));
		}
		
		$sql = "insert into productdetail(id,lot,make,model,start,auction,auction_date,mileage,year,images,enginecc,chassis,grade,color,transmission,rate,avg_price,serial) values('{$obj->ID}','{$obj->LOT}','{$obj->MARKA_NAME}','{$obj->MODEL_NAME}','{$obj->START}','{$obj->AUCTION}','{$obj->AUCTION_DATE}','{$obj->MILEAGE}','{$obj->YEAR}','{$newimgurl}','{$obj->ENG_V}','{$obj->KUZOV}','{$obj->GRADE}','{$obj->COLOR}','{$obj->KPP}','{$obj->RATE}','{$obj->AVG_PRICE}','{$obj->SERIAL}')";

		if ($conn->query($sql) === TRUE) {
			$response['Status'] = "Done";
		} else {
			$response['Status'] = "Error: " . $conn->error;
		}
	}
	
	$sql = "insert into wishlist(p_id,userid,wishlist) values('{$pid}','{$userid}','{$wishlist}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 
		
 }
 else
 {
	$sql = "delete from wishlist where userid = '{$userid}' AND p_id = '{$pid}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}
 }

$conn->close();  
	
echo json_encode($response);
	 
	
?>