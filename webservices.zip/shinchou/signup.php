<?php
header("Content-Type: application/json");

require('db_con.php');

$email = $_GET['email'];
$fname = $_GET['fname'];
$lname = $_GET['lname'];
$password = $_GET['password'];
$country = $_GET['country'];
$city = $_GET['city'];
$company = $_GET['company'];
$phone = $_GET['phone'];

$sql = "select * from auth where email = '{$email}'";

$result = $conn->query($sql);

$i = '';

while($row = $result->fetch_assoc()) {
 	$i = $row['email'];     	
}

if($i != '')
{
    $response['Status'] = "Email";
}
else if($i === '')
{
    $sql = "INSERT INTO auth (email, fname, lname, password, country, city, company, phone,approval) VALUES ('{$email}','{$fname}','{$lname}','{$password}','{$country}','{$city}','{$company}','{$phone}','Pending')";

if ($conn->query($sql) === TRUE) {
    $response['Status'] = "Registered";
	$response['userid'] = $email;
} else {
    $response['Status'] = "Error: " . $conn->error;
}
	
}

$conn->close();   
	

echo json_encode($response);
	 
	
?>