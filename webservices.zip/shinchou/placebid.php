<?php
header("Content-Type: application/json");

require('db_con.php');

$prodid = $_POST['prodid'];
$userid = $_POST['userid'];
$estprice = $_POST['estprice'];
$bidmsg = $_POST['bidmsg'];
$dtetme = $_POST['datetme'];
$foruser = $_POST['foruser'];
$objw = array('a' => 1);
$email = '';

    $subsql1 = "SELECT email from userauth where username = '{$userid}'";

	$subresult1 = $conn->query($subsql1);

	while($row = $subresult1->fetch_assoc()) {			
	 $email = $row['email'];   		   
	}

	$subsql = "SELECT lot from productdetail where id = '{$prodid}'";

	$subresult = $conn->query($subsql);

	$cond = false;

	while($row = $subresult->fetch_assoc()) {			
		$cond = true;		   
	}
	 
		$json = file_get_contents('http://75.125.226.218/xml/json?code=Vdf3_ryhAjmf7&sql=select%20*%20from%20main%20where%20id%20=%20%27'. $prodid .'%27');
		$json = substr($json,1);
		$json = substr($json,0,strlen($json) - 1);
		$obj = json_decode($json);
		
		$imgs = $obj->IMAGES;

		$imgsplit = explode("#",$imgs);
		$newimgurl = '';
		for($i = 0; $i < sizeof($imgsplit); $i++)
		{
			$url = $imgsplit[$i];
			$img = 'uploads/' . 'img' . $i . $obj->ID . '.jpg';
			$newimgurl .= "http://".$_SERVER["HTTP_HOST"].substr($_SERVER["REQUEST_URI"],0,strrpos($_SERVER["REQUEST_URI"], "/") + 1) . $img."#";
			file_put_contents($img, file_get_contents($url));
		}
	
	if($cond === false)
	{
		$sql = "insert into productdetail(id,lot,make,model,start,auction,auction_date,mileage,year,images,enginecc,chassis,grade,color,transmission,rate,avg_price,serial) values('{$obj->ID}','{$obj->LOT}','{$obj->MARKA_NAME}','{$obj->MODEL_NAME}','{$obj->START}','{$obj->AUCTION}','{$obj->AUCTION_DATE}','{$obj->MILEAGE}','{$obj->YEAR}','{$newimgurl}','{$obj->ENG_V}','{$obj->KUZOV}','{$obj->GRADE}','{$obj->COLOR}','{$obj->KPP}','{$obj->RATE}','{$obj->AVG_PRICE}','{$obj->SERIAL}')";

		if ($conn->query($sql) === TRUE) {
			$response['Status'] = "Done";
		} else {
			$response['Status'] = "Error: " . $conn->error;
		}
	}


	$sql = "insert into bids(prodid,user_id,for_user,estprice,bidmsg,datetme) values('{$prodid}','{$userid}','{$foruser}','{$estprice}', '{$bidmsg}','{$dtetme}')";

	if ($conn->query($sql) === TRUE) {
	    
	    $sfr = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
  
  <title>Email Format</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  
 <style>
 h3{
 margin:5px;
 padding:10px;
 font-family: Calibri;
 }
 
 span
 {
	font-size:14px;
	color:#333;
 }
 </style>
  
 </head>
<body style="margin: 0; padding: 0;">
 <table align="center" cellpadding="0" cellspacing="0" style="border-collapse: collapse;">';
 
 $sfr_user = $sfr;
 
$sfr .= '<tr style="border-bottom:1px solid #999;text-align:center">
  <td colspan="2"><h3>NEW BID BY USER `' . $userid .  '`</h3></td>
 </tr>
<tr>
	<td style="width:25%; padding:10px;text-align:justify; border-right:1px solid #999;border-bottom:1px solid #999">
		<p>
		<b>' . $obj->YEAR . ' ' . $obj->MARKA_NAME . ' ' . $obj->MODEL_NAME . '</b>
		<br/>
		Bid Amount: ¥ '  . $estprice . ' '  . $obj->AUCTION . ' '  . $obj->MILEAGE . 'km '  . $obj->ENG_V . 'cc '  . $obj->LOT . ' '  . $obj->KUZOV . ' '  . $obj->KPP . '
		</p>
	</td>
	<td style="width:75%;border-bottom:1px solid #999">
		<table>
			<tr>';
			
$sfr_user .= '<tr style="border-bottom:1px solid #999;text-align:center">
  <td colspan="2"><h3>YOUR BID HAS BEEN PLACED!</h3></td>
 </tr>
<tr>
	<td style="width:25%; padding:10px;text-align:justify; border-right:1px solid #999;border-bottom:1px solid #999">
		<p>
		<b>' . $obj->YEAR . ' ' . $obj->MARKA_NAME . ' ' . $obj->MODEL_NAME . '</b>
		<br/>
		Bid Amount: ¥ '  . $estprice . ' '  . $obj->AUCTION . ' '  . $obj->MILEAGE . 'km '  . $obj->ENG_V . 'cc '  . $obj->LOT . ' '  . $obj->KUZOV . ' '  . $obj->KPP . '
		</p>
	</td>
	<td style="width:75%;border-bottom:1px solid #999">
		<table>
			<tr>';
			
		for($f = 0; $f < sizeof($imgsplit); $f++)
		{
			$sfr .= '<td style="25%"><img src="' . $imgsplit[$f] .'" height="100"/></td>';
			$sfr_user .= '<td style="25%"><img src="' . $imgsplit[$f] .'" height="100"/></td>';
			
			if($f == 4 || $f == 8)
			{
				$sfr .= '</tr><tr>';
				$sfr_user .= '</tr><tr>';
			}			
		}

$sfr .='</tr></table>
	</td>
</tr>';

$sfr_user .='</tr></table>
	</td>
</tr>';

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

 
$sfr.= '
</table>
</body>
</html>';

$sfr_user.= '
</table>
</body>
</html>';
	    
	    if(mail('ansari@shinchuo.com',"New Bid by User " . $userid,$sfr, $headers))
        {
            mail($email,"New Bid Placed",$sfr_user, $headers);
		    $response['Status'] = "Done";
        }
        else
        {
            $respone['Status'] = "Bid Placed! Email not Sent!";
        }
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 
 

    $conn->close();  
	
echo json_encode($response);
	 
	
?>