<?php
header("Content-Type: application/json");

require('db_con.php');

$sql = "SELECT * from vehicle";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["v_id"] = $row["v_id"];       	
$arr[$i]["make"] = $row["make"];
$arr[$i]["mod"] = $row["model"];
$arr[$i]["prefix"] = $row["prefix"];
$arr[$i]["year"] = $row["year"];
$arr[$i]["length"] = $row["length"];
$arr[$i]["width"] = $row["width"];
$arr[$i]["height"] = $row["height"];
$arr[$i]["m3"] = $row["m3"];
$arr[$i]["kgs"] = $row["kgs"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>