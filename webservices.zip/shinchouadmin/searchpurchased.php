<?php
header("Content-Type: application/json");

require('db_con.php');

$s_code = $_POST["scode"];
$client = $_POST["client"];
$dst = $_POST["dst"];
$auction = $_POST["auction"];
$adate = $_POST["adate"];
$pos = $_POST["pos"];
$dai = $_POST["dai"];
$lot = $_POST["lot"];
$prefix = $_POST["prefix"];
$serial = $_POST["serial"];
$make = $_POST["make"];
$model = $_POST["model"];
$year = $_POST["year"];
$bidprice = $_POST["bidprice"];
$aucfee = $_POST["aucfee"];
$exportcharge = $_POST["exportcharge"];
$noplate = $_POST["noplate"];
$plateserial = $_POST["plateserial"];
$shaken = $_POST["shaken"];
$fudosha = $_POST["fudosha"];
$transmission = $_POST["transmission"];
$enginecc = $_POST["enginecc"];
$mileage = $_POST["mileage"];
$color = $_POST["color"];
$colorcode = $_POST["colorcode"];
$buyingcom = $_POST["buyingcom"];
$buyer = $_POST["buyer"];
$remark = $_POST["remark"];
$landedvalue = $_POST["landedvalue"];
$soldprice = $_POST["soldprice"];
$role = $_POST["role"];
$aucs = $_POST["aucs"];

if($s_code == 'undefined')       {$s_code = '';}
if($client == 'undefined')       {$client = '';}
if($dst == 'undefined')          {$dst    = '';}
if($auction == 'undefined')      {$auction = '';}
if($adate == 'undefined')        {$adate  = '';}
if($pos == 'undefined')          {$pos    = '';}
if($dai == 'undefined')          {$dai    = '';}
if($lot == 'undefined')          {$lot    = '';}
if($prefix == 'undefined')       {$prefix = '';}
if($serial == 'undefined')       {$serial = '';}
if($make == 'undefined')         {$make   = '';}
if($model == 'undefined')        {$model  = '';}
if($year == 'undefined')         {$year   = '';}
if($bidprice == 'undefined')     {$bidprice = '';}
if($aucfee == 'undefined')       {$aucfee  = '';}
if($exportcharge == 'undefined') {$exportcharge= '';}
if($noplate == 'undefined')      {$noplate = '';}
if($plateserial == 'undefined')  {$plateserial = '';}
if($shaken == 'undefined')       {$shaken = '';}
if($fudosha == 'undefined')      {$fudosha = '';}
if($transmission == 'undefined') {$transmission= '';}
if($enginecc == 'undefined')     {$enginecc = '';}
if($mileage == 'undefined')      {$mileage = '';}
if($color == 'undefined')        {$color = '';}
if($colorcode == 'undefined')    {$colorcode = '';}
if($buyingcom == 'undefined')    {$buyingcom = '';}
if($buyer == 'undefined')        {$buyer = '';}
if($remark == 'undefined')       {$remark = '';}
if($landedvalue == 'undefined')  {$landedvalue = '';}
if($soldprice == 'undefined')    {$soldprice = '';}

if($role == 'admin')
{
	$sql = "SELECT *,(select images from productdetail where id = purchasedlist.prodid) as images from purchasedlist where s_code LIKE '%{$s_code}%' && client LIKE '%{$client}%' && dst LIKE '%{$dst}%' && auction LIKE '%{$auction}%' && adate LIKE '%{$adate}%' && pos LIKE '%{$pos}%' && dai LIKE '%{$dai}%' && lot LIKE '%{$lot}%' && prefix LIKE '%{$prefix}%' && serial LIKE '%{$serial}%' && make LIKE '%{$make}%' && model LIKE '%{$model}%' && year LIKE '%{$year}%' && bidprice LIKE '%{$bidprice}%' && aucfee LIKE '%{$aucfee}%' && exportcharge LIKE '%{$exportcharge}%' && noplate LIKE '%{$noplate}%' && plateserial LIKE '%{$plateserial}%' && shaken LIKE '%{$shaken}%' && fudosha LIKE '%{$fudosha}%' && transmission LIKE '%{$transmission}%' && enginecc LIKE '%{$enginecc}%' && mileage LIKE '%{$mileage}%' && color LIKE '%{$color}%' && colorcode LIKE '%{$colorcode}%' && buyingcom LIKE '%{$buyingcom}%' && buyer LIKE '%{$buyer}%' && remark LIKE '%{$remark}%' && landedvalue LIKE '%{$landedvalue}%' && soldprice LIKE '%{$soldprice}%'" . $aucs; 
}
else
{
	$sql = "SELECT *,(select images from productdetail where id = purchasedlist.prodid) as images from purchasedlist where s_code LIKE '%{$s_code}%' && client LIKE '%{$client}%' && dst LIKE '%{$dst}%' && auction LIKE '%{$auction}%' && adate LIKE '%{$adate}%' && pos LIKE '%{$pos}%' && dai LIKE '%{$dai}%' && lot LIKE '%{$lot}%' && prefix LIKE '%{$prefix}%' && serial LIKE '%{$serial}%' && make LIKE '%{$make}%' && model LIKE '%{$model}%' && year LIKE '%{$year}%' && bidprice LIKE '%{$bidprice}%' && aucfee LIKE '%{$aucfee}%' && exportcharge LIKE '%{$exportcharge}%' && noplate LIKE '%{$noplate}%' && plateserial LIKE '%{$plateserial}%' && shaken LIKE '%{$shaken}%' && fudosha LIKE '%{$fudosha}%' && transmission LIKE '%{$transmission}%' && enginecc LIKE '%{$enginecc}%' && mileage LIKE '%{$mileage}%' && color LIKE '%{$color}%' && colorcode LIKE '%{$colorcode}%' && buyingcom LIKE '%{$buyingcom}%' && buyer LIKE '%{$buyer}%' && remark LIKE '%{$remark}%' && landedvalue LIKE '%{$landedvalue}%' && soldprice LIKE '%{$soldprice}%'" . $aucs; 
}

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {      	
$arr[$i]["s_id"] = $row["s_id"];  
$arr[$i]["prodid"] = $row["prodid"];
$arr[$i]["images"] = $row["images"];     	
$arr[$i]["s_code"] = $row["s_code"];
$arr[$i]["client"] = $row["client"];
$arr[$i]["dst"] = $row["dst"];
$arr[$i]["auction"] = $row["auction"];
$arr[$i]["adate"] = $row["adate"];
$arr[$i]["pos"] = $row["pos"];
$arr[$i]["dai"] = $row["dai"];
$arr[$i]["lot"] = $row["lot"];
$arr[$i]["prefix"] = $row["prefix"];
$arr[$i]["serial"] = $row["serial"];
$arr[$i]["make"] = $row["make"];
$arr[$i]["model"] = $row["model"];
$arr[$i]["year"] = $row["year"];
$arr[$i]["bidprice"] = $row["bidprice"];
$arr[$i]["aucfee"] = $row["aucfee"];
$arr[$i]["exportcharge"] = $row["exportcharge"];
$arr[$i]["noplate"] = $row["noplate"];
$arr[$i]["plateserial"] = $row["plateserial"];
$arr[$i]["shaken"] = $row["shaken"];
$arr[$i]["fudosha"] = $row["fudosha"];
$arr[$i]["transmission"] = $row["transmission"];
$arr[$i]["enginecc"] = $row["enginecc"];
$arr[$i]["mileage"] = $row["mileage"];
$arr[$i]["color"] = $row["color"];
$arr[$i]["colorcode"] = $row["colorcode"];
$arr[$i]["buyingcom"] = $row["buyingcom"];
$arr[$i]["buyer"] = $row["buyer"];
$arr[$i]["remark"] = $row["remark"];
$arr[$i]["landedvalue"] = $row["landedvalue"];
$arr[$i]["soldprice"] = $row["soldprice"];
$arr[$i]["status"] = $row["status"];
$arr[$i]["stocksold"] = $row["stocksold"];
$arr[$i]["sellingprice"] = $row["sellingprice"];
$arr[$i]["showsellprice"] = $row["showsellprice"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>