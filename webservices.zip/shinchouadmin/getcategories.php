<?php
header("Content-Type: application/json");

require('db_con.php');

$sql = "SELECT * from category";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {

$arr[$i]["ID"] = $row["cat_id"];       	
$arr[$i]["name"] = $row["cat"];
$arr[$i]["createdon"] = $row["createdon"];
$arr[$i]["createdby"] = $row["createdby"];
	   
	  $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>