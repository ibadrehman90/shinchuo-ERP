<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$bname = $_POST['bname'];
$username = $_POST['username'];
$pass = $_POST['pass'];
$mob = $_POST['mob'];
$country = $_POST['country'];
$email = $_POST['email'];
$city = $_POST['city'];
$status = $_POST['status'];
$showlcc = $_POST['showlcc'];
$role = $_POST['role'];
$salesuser = '';

if($role == 'salesuser')
{
$salesuser = $username;    
}
else
{
    $salesuser = '';
}

$sql = "select email from userauth where email = '{$email}'";

$result = $conn->query($sql);

$i = 0;

while($row = $result->fetch_assoc()) {
 	$i++;     	
}

if($i == 0)
{

	$sql = "insert into userauth(username,password,email,name,city,country,mobile,status,showlcc,salesuser,role,profileimg, colorscheme) values('{$username}','{$pass}','{$email}','{$bname}','{$city}','{$country}','{$mob}','{$status}','{$showlcc}','{$salesuser}','{$role}','http://shinchuo-test2.com/shinchouadmin/userprofiles/default_user.jpg', '#ed3338')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
		
		if (strpos($response['Status'], 'PRIMARY') !== false) {
			$response['Status'] = 'UserExist';
		}
	}

}
else
{
	$response['Status'] = "Exist";
}

}

$conn->close();  

echo json_encode($response);
?>