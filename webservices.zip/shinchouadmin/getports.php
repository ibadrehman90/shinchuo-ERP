<?php
header("Content-Type: application/json");

require('db_con.php');

$country = $_POST["country"];

$sql = "SELECT * from ports where country = '{$country}' AND approval = 1";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["port_id"] = $row["port_id"];       	
$arr[$i]["port"] = $row["port"];
$arr[$i]["country"] = $row["country"];
$arr[$i]["generatedby"] = $row["generatedby"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>