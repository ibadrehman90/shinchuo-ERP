<?php
header("Content-Type: application/json");

require('db_con.php');

$lot = $_POST['lot'];
$make = $_POST['make'];
$model = $_POST['model'];
$chassis = $_POST['chassis'];
$auction = $_POST['auction'];
$salesusers = $_POST['salesuser'];
$client = $_POST['client'];
$bfrom = $_POST['bfrom'];
$bto = $_POST['bto'];
$cat = $_POST['type'];
$aucs = $_POST['aucs'];
$role = $_POST['role'];

if($lot == 'undefined')
	$lot = '';

if($make == 'undefined')
	$make = '';

if($model == 'undefined')
	$model = '';

if($chassis == 'undefined')
	$chassis = '';

if($salesusers == 'undefined')
	$salesusers = '';

if($client == 'undefined')
	$client = '';

if($auction == 'undefined')
	$auction = '';

if($bfrom == 'undefined')
	$bfrom = '';

if($bto == 'undefined')
	$bto = '';

$partsql = '';

if($role == 'admin')
{
if($cat == 'latest')
$partsql = " && auction_date >= '". date("Y-m-d") . "' AND status = 0";

else if($cat == 'archived')
$partsql = " && (auction_date < '". date("Y-m-d") . "' OR (auction_date >= '". date("Y-m-d") . "' AND status != 0))";
}
else
{
if($cat == 'latest')
$partsql = " && auction_date >= '". date("Y-m-d") . "' AND status = 0" . $aucs;

else if($cat == 'archived')
$partsql = " && (auction_date < '". date("Y-m-d") . "' OR (auction_date >= '". date("Y-m-d") . "' AND status != 0))" . $aucs;	
}

$sql = "SELECT * from bids inner join productdetail on bids.prodid = productdetail.id where lot LIKE '%{$lot}%' && make LIKE '%{$make}%' && model LIKE '%{$model}%' && chassis LIKE '%{$chassis}%' && for_user LIKE '%{$salesusers}%' && user_id LIKE '%{$client}%' && auction LIKE '%{$auction}%' && auction_date >= '{$bfrom}' && auction_date <= '{$bto}'" . $partsql;

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["b_id"] = $row["b_id"];       	
$arr[$i]["auction"] = $row["auction"];
$arr[$i]["auctiondate"] = $row["auction_date"];
$arr[$i]["lot"] = $row["lot"];
$arr[$i]["chassis"] = $row["chassis"];
$arr[$i]["make"] = $row["make"];
$arr[$i]["model"] = $row["model"];
$arr[$i]["year"] = $row["year"];
$arr[$i]["estprice"] = $row["estprice"];
$arr[$i]["user_id"] = $row["user_id"];
$arr[$i]["bidmsg"] = $row["bidmsg"];
$arr[$i]["status"] = $row["status"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>