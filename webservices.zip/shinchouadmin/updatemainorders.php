<?php
header("Content-Type: application/json");

require('db_con.php');

$cat = $_POST['cat'];
$val = $_POST['val'];
$sid = $_POST['sid'];


	$sql = "update orders set {$cat} = '{$val}' where orderno = '{$sid}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>