<?php
header("Content-Type: application/json");

require('db_con.php');

$sql = "SELECT DISTINCT(cname) from lccsetting";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {      	
$arr[$i]["cname"] = $row["cname"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>