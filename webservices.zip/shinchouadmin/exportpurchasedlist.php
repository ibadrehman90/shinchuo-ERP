<?php

require('db_con.php');

$username = $_POST['username'];

$sql = "SELECT * from purchasedlist";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["s_id"] = $i + 1; 
//$arr[$i]["prodid"] = $row["prodid"];
//$arr[$i]["images"] = $row["images"];       	
$arr[$i]["s_code"] = $row["s_code"];
$arr[$i]["client"] = $row["client"];
$arr[$i]["dst"] = $row["dst"];
$arr[$i]["auction"] = $row["auction"];
$arr[$i]["adate"] = $row["adate"];
$arr[$i]["pos"] = $row["pos"];
$arr[$i]["dai"] = $row["dai"];
$arr[$i]["lot"] = $row["lot"];
$arr[$i]["prefix"] = $row["prefix"];
$arr[$i]["serial"] = $row["serial"];
$arr[$i]["make"] = $row["make"];
$arr[$i]["model"] = $row["model"];
$arr[$i]["year"] = $row["year"];
$arr[$i]["bidprice"] = $row["bidprice"];
$arr[$i]["aucfee"] = $row["aucfee"];
$arr[$i]["exportcharge"] = $row["exportcharge"];
$arr[$i]["noplate"] = $row["noplate"];
$arr[$i]["plateserial"] = $row["plateserial"];
$arr[$i]["shaken"] = $row["shaken"];
$arr[$i]["fudosha"] = $row["fudosha"];
$arr[$i]["transmission"] = $row["transmission"];
$arr[$i]["enginecc"] = $row["enginecc"];
$arr[$i]["mileage"] = $row["mileage"];
$arr[$i]["color"] = $row["color"];
$arr[$i]["colorcode"] = $row["colorcode"];
$arr[$i]["buyingcom"] = $row["buyingcom"];
$arr[$i]["buyer"] = $row["buyer"];
$arr[$i]["remark"] = $row["remark"];
$arr[$i]["landedvalue"] = $row["landedvalue"];
$arr[$i]["soldprice"] = $row["soldprice"];
//$arr[$i]["status"] = $row["status"];
//$arr[$i]["stocksold"] = $row["stocksold"];
//$arr[$i]["sellingprice"] = $row["sellingprice"];
//$arr[$i]["showsellprice"] = $row["showsellprice"];
	   
	   $i++;
    }

$conn->close();	

// output headers so that the file is downloaded rather than displayed
header('Content-type: text/csv');
header('Content-Disposition: attachment; filename="purchasedlist.csv"');
 
// do not cache the file
header('Pragma: no-cache');
header('Expires: 0');
 
// create a file pointer connected to the output stream
$file = fopen('php://output', 'w');
 
// send the column headers
fputcsv($file, array('S.No.', 'S-CODE', 'USER', 'DST', 'AUCTION', 'AUCTION DATE  ', 'POS', 'DAI', 'LOT','PREFIX','SERIAL','MAKE', 'MODEL', 'YEAR', 'BID PRICE', 'AUCTION FEE', 'EXPORT CHARGE', 'NO PLATE', 'PLATE SERIAL', 'SHAKEN', 'FUDOSHA' , 'TRANSMISSION' , 'CC' , 'MILEAGE', 'COLOR', 'COLOR CODE', 'BUYING COMMISSION', 'BUYER' , 'REMARK', 'LANDED VALUE', 'SOLD PRICE'));
 
// Sample data. This can be fetched from mysql too
$data = $arr;
 
// output each row of the data
foreach ($data as $row)
{
fputcsv($file, $row);
}
 

 	 
 	 ?>