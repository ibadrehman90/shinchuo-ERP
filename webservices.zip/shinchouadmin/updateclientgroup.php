<?php
header("Content-Type: application/json");

require('db_con.php');

$gid = $_POST['gid'];
$status = $_POST['status'];


	$sql = "update clientgroup set status = '{$status}' where g_id = {$gid}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>