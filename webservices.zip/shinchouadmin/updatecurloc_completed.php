<?php
header("Content-Type: application/json");

require('db_con.php');

$ordercode = $_POST['ordercode'];

$yardname = '';
$pid = '';
$ordlist = '';

$sqls = "select p_id, (select name from yard where yard.y_id = orders.y_id) as yardname from orderdetail inner join orders on orderdetail.ord_id = orders.orderno where orderno = '{$ordercode}'";
    
    $results = $conn->query($sqls);
    
    while($rows = $results->fetch_assoc()) {
     	     $yardname = $rows['yardname'];
     	     $pid = $rows['p_id'];
     	     
     	     $ordlist .= "update purchasedlist set currentloc = '{$yardname}' where s_id = '{$pid}';";
    }
    
    $sql = $ordlist;


	if ($conn->multi_query($sql) === TRUE) {
		
		do
		{
			// Store first result set
			if ($result1=mysqli_store_result($conn)) {
			  // Fetch one and one row
			  while ($row1=mysqli_fetch_row($result1))
				{
				printf("%s\n",$row1[0]);
				}
			  // Free result set
			  mysqli_free_result($result1);
			  }
		}
		while (mysqli_next_result($conn));
		
		$response['Status'] = 'Done';
	} else {
		$response['Status'] = "Error: " . $conn->error;		
	}


$conn->close();  
	
echo json_encode($response);
	 
	
?>