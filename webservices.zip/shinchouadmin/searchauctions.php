<?php
header("Content-Type: application/json");

require('db_con.php');

$aname = $_POST['aname'];
$pos = $_POST['pos'];
$tel = $_POST['tel'];
$cname = $_POST['cname'];
$fax = $_POST['fax'];
$email = $_POST['email'];

if($aname == 'undefined')
	$aname = '';

if($pos == 'undefined')
	$pos = '';

if($tel == 'undefined')
	$tel = '';

if($cname == 'undefined')
	$cname = '';

if($fax == 'undefined')
	$fax = '';

if($email == 'undefined')
	$email = '';

$sql = "SELECT * from auction where aname LIKE '%{$aname}%' && pos LIKE '%{$pos}%' && tel LIKE '%{$tel}%' && cname LIKE '%{$cname}%' && fax LIKE '%{$fax}%' && email LIKE '%{$email}%'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["a_id"] = $row["a_id"];       	
$arr[$i]["aname"] = $row["aname"];
$arr[$i]["pos"] = $row["pos"];
$arr[$i]["tel"] = $row["tel"];
$arr[$i]["fax"] = $row["fax"];
$arr[$i]["cname"] = $row["cname"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["statustime"] = $row["statustime"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>