<?php
header("Content-Type: application/json");

require('db_con.php');

$username = $_POST['username'];

$sql = "SELECT auction from assignauction where b_email = '{$username}' AND status = 1";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
      	
$arr[$i]["auction"] = $row["auction"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>