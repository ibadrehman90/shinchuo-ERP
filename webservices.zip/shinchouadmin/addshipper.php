<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$sname = $_POST['sname'];
$cperson = $_POST['cperson'];
$tel = $_POST['tel'];
$mob = $_POST['mob'];
$fax = $_POST['fax'];
$email = $_POST['email'];
$dte = $_POST['dte'];

	$sql = "insert into shipper(sname, cperson, email, phone, mobile, fax, statustime, status) values('{$sname}','{$cperson}','{$email}','{$tel}','{$mob}','{$fax}','{$dte}',1)";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

}

$conn->close();  

echo json_encode($response);
?>