<?php
header("Content-Type: application/json");

require('db_con.php');

$aid = $_POST['aid'];
$status = $_POST['status'];


	$sql = "update assignauction set status = '{$status}' where a_id = '{$aid}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>