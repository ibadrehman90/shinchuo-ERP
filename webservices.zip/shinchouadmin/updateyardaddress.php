<?php
header("Content-Type: application/json");

require('db_con.php');

$y_id = $_POST['y_id'];
$name = $_POST['name'];
$address = $_POST['address'];
$billingaddress = $_POST['billingaddress'];
$city = $_POST['city'];
$country = $_POST['country'];
$pos = $_POST['pos'];
$prefacture = $_POST['prefacture'];
$dte = $_POST['dte'];


	$sql = "update yard set name = '{$name}',address = '{$address}',billingaddress = '{$billingaddress}',city = '{$city}',country = '{$country}',pos = '{$pos}',prefacture = '{$prefacture}', statustime = '{$dte}' where y_id = {$y_id}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>