<?php
header("Content-Type: application/json");

require('db_con.php');

$s_id = $_POST['s_id'];
$status = $_POST['status'];


	$sql = "update transport set status = '{$status}' where s_id = {$s_id}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>