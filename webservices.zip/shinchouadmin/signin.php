<?php
header("Content-Type: application/json");

require('db_con.php');

$email = $_GET['email'];
$password = $_GET['password'];

$response['Status'] = "null";

$sql = "SELECT * from userauth where email = '". $email . "' AND role != 'client'";

$result = $conn->query($sql);

 while($row = $result->fetch_assoc()) {
        		
		if($row['password'] == $password)
		{
			$response['Status'] = "Auth";
			$response['userid']	= $row['username'];
			$response['userrole']	= $row['role'];
		}
		else
		{
			$response['Status'] = "No";
		}
}

$conn->close();	

echo json_encode($response);
	 
	
?>