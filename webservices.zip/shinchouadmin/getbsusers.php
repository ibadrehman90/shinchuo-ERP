<?php
header("Content-Type: application/json");

require('db_con.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$role = $_POST['role'];

$sql = "SELECT * from userauth where role = '{$role}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["username"] = $row["username"];       	
$arr[$i]["bname"] = $row["name"];
$arr[$i]["city"] = $row["city"];
$arr[$i]["country"] = $row["country"];
$arr[$i]["mob"] = $row["mobile"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["status"] = $row["status"];
$arr[$i]["showlcc"] = $row["showlcc"];
	   
	   $i++;
    }
	
}
$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>