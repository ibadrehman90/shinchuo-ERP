<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$orderno = $_POST['orderno'];
$ordlist = $_POST['ordlist'];
$orddate = $_POST['orddate'];
$trackingno = $_POST['trackingno'];
$timeslot = $_POST['timeslot'];
$aucid = $_POST['aucid'];
$tcompid = $_POST['tcompid'];
$remarks = $_POST['remarks'];
$user = $_POST['username'];

$ordlist = substr($ordlist,0,strlen($ordlist) - 1);
$ordlists = explode("|", $ordlist);

$finalordlists = '';

foreach ($ordlists as $value) {
   $finalordlists .= "insert into deliverydetail(sp_id,deliveryno) values('{$value}','{$orderno}'); update orderdetail set status = '1' where p_id = {$value};";
}

$sql = "select * from delivery where deliveryno = '{$orderno}'";

$result = $conn->query($sql);

$i = 0;

while($row = $result->fetch_assoc()) {
 	$i++;     	
}

if($i == 0)
{
    $dte = date("d-m-Y");
    $tme = date("h:i:sa");

	$sql = "insert into delivery(deliveryno, deliverydate, aucid, tid, trackingno, timeslot, remark, inputby, inputdate, inputtime) values('{$orderno}','{$orddate}','{$aucid}','{$tcompid}','{$trackingno}','{$timeslot}','{$remarks}','{$user}','{$dte}','{$tme}');" . $finalordlists;

	if ($conn->multi_query($sql) === TRUE) {
		
		do
		{
			// Store first result set
			if ($result1=mysqli_store_result($conn)) {
			  // Fetch one and one row
			  while ($row1=mysqli_fetch_row($result1))
				{
				printf("%s\n",$row1[0]);
				}
			  // Free result set
			  mysqli_free_result($result1);
			  }
		}
		while (mysqli_next_result($conn));
		
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;		
	}
	
}
else
{
	$sql = $finalordlists;

	if ($conn->multi_query($sql) === TRUE) {
		
		do
		{
			// Store first result set
			if ($result1=mysqli_store_result($conn)) {
			  // Fetch one and one row
			  while ($row1=mysqli_fetch_row($result1))
				{
				printf("%s\n",$row1[0]);
				}
			  // Free result set
			  mysqli_free_result($result1);
			  }
		}
		while (mysqli_next_result($conn));
		
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;		
	}
}
}

$conn->close();  

echo json_encode($response);
?>