<?php
header("Content-Type: application/json");
require('db_con.php');

$country = $_POST['country'];
$make = $_POST['make'];
$makelist = $_POST['makelist'];
$otherlist = $_POST['otherlist'];

$sql = "SELECT * from custommodel where country = '{$country}' AND make = '{$make}'";

$result = $conn->query($sql);

$cid = false;

 while($row = $result->fetch_assoc()) {	
	
	$cid = true;		   
 }
 
 if($cid == false)
 {

	$sql = "insert into custommodel(country, make, modellist, otherlist) values('{$country}','{$make}','{$makelist}','{$otherlist}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 
		
 }
 else
 {
	$sql = "update custommodel set modellist = '{$makelist}', otherlist = '{$otherlist}' where country = '{$country}' AND make = '{$make}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}
 }

$conn->close();  
	
echo json_encode($response);
	 
	
?>