<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


$make = $_POST['make'];
$mod = $_POST['mod'];
$prefix = $_POST['prefix'];
$year = $_POST['year'];
$length = $_POST['length'];
$width = $_POST['width'];
$height = $_POST['height'];
$m3 = $_POST['m3'];
$kgs = $_POST['kgs'];

	$sql = "insert into vehicle(make,model,prefix,year,length,width,height,m3,kgs) values('{$make}','{$mod}','{$prefix}','{$year}','{$length}','{$width}','{$height}','{$m3}','{$kgs}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

}

$conn->close();  

echo json_encode($response);
?>