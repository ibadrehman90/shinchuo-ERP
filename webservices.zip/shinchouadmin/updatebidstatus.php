<?php
header("Content-Type: application/json");

require('db_con.php');

$b_id = $_POST['b_id'];
$status = $_POST['status'];


	$sql = "update bids set status = '{$status}' where b_id = {$b_id}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>