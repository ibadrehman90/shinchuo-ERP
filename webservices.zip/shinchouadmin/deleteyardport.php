<?php
header("Content-Type: application/json");

require('db_con.php');

$tab = $_POST['tab'];
$cat = $_POST['cat'];
$val = $_POST['val'];


	$sql = "delete from {$tab} where {$cat} = '{$val}'";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>