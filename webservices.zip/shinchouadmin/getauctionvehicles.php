<?php
header("Content-Type: application/json");

require('db_con.php');

$sql = "select auction, adate, count(*) as units, GROUP_CONCAT(CONCAT(make,'-',model)) as make from purchasedlist group by auction";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {

$arr[$i]["auction"] = $row["auction"];
$arr[$i]["adate"] = $row["adate"];
$arr[$i]["units"] = $row["units"];
$arr[$i]["make"] = $row["make"];
	   
	  $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>