<?php
header("Content-Type: application/json");

require('db_con.php');

$username = $_POST['email'];

$sql = "SELECT * from userauth where username = '{$username}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["username"] = $row["username"];
$arr[$i]["email"] = $row["email"];       	
$arr[$i]["mob"] = $row["mobile"];
$arr[$i]["name"] = $row["name"];
$arr[$i]["address"] = $row["address"];
$arr[$i]["port"] = $row["port"];
$arr[$i]["company"] = $row["company"];
$arr[$i]["country"] = $row["country"];
$arr[$i]["city"] = $row["city"];
	   
	  $i++;
}

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>