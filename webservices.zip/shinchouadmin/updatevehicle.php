<?php
header("Content-Type: application/json");

require('db_con.php');

$v_id = $_POST['v_id'];
$make = $_POST['make'];
$mod = $_POST['mod'];
$prefix = $_POST['prefix'];
$year = $_POST['year'];
$length = $_POST['length'];
$width = $_POST['width'];
$height = $_POST['height'];
$m3 = $_POST['m3'];
$kgs = $_POST['kgs'];


	$sql = "update vehicle set make = '{$make}',model = '{$mod}',prefix = '{$prefix}',year = '{$year}',length = '{$length}',width = '{$width}', height = '{$height}', m3 = '{$m3}', kgs = '{$kgs}' where v_id = {$v_id}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>