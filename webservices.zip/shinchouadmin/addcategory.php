<?php
header("Content-Type: application/json");

require('db_con.php');

$cat = $_GET['cat'];
$authid = $_GET['authid'];
$dte = $_GET['dte'];


	$sql = "insert into category(cat,createdon,createdby) values('{$cat}','{$authid}','{$dte}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>