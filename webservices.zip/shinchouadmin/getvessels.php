<?php
header("Content-Type: application/json");

require('db_con.php');

$sql = "SELECT * from vessel";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["v_id"] = $row["v_id"];       	
$arr[$i]["bno"] = $row["bno"];
$arr[$i]["sname"] = $row["sname"];
$arr[$i]["voyage"] = $row["voyage"];
$arr[$i]["cut"] = $row["cut"];
$arr[$i]["cyopen"] = $row["cyopen"];
$arr[$i]["etd"] = $row["etd"];
$arr[$i]["eta"] = $row["eta"];
$arr[$i]["v_from"] = $row["v_from"];
$arr[$i]["v_to"] = $row["v_to"];
$arr[$i]["reserved"] = $row["reserved"];
$arr[$i]["agent"] = $row["agent"];
$arr[$i]["carrier"] = $row["carrier"];
$arr[$i]["statustime"] = $row["statustime"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>