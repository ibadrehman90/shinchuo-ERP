<?php
header("Content-Type: application/json");

require('db_con.php');

$username = $_POST['username'];
$pass = $_POST['pass'];


	$sql = "update userauth set password = '{$pass}' where username = '{$username}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>