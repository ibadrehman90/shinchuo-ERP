<?php
header("Content-Type: application/json");

require('db_con.php');

$y_id = $_POST['y_id'];
$name = $_POST['name'];
$address = $_POST['address'];
$clearance = $_POST['clearance'];
$ward = $_POST['ward'];
$city = $_POST['city'];
$country = $_POST['country'];
$pos = $_POST['pos'];
$tel = $_POST['tel'];
$fax = $_POST['fax'];
$prefacture = $_POST['prefacture'];
$yusage = $_POST['yusage'];
$email = $_POST['email'];
$cname = $_POST['cname'];
$cmob = $_POST['cmob'];
$dte = $_POST['dte'];


	$sql = "update yard set name = '{$name}',address = '{$address}',clearance = '{$clearance}',ward = '{$ward}',city = '{$city}',country = '{$country}',pos = '{$pos}',email = '{$email}',tel = '{$tel}',prefacture = '{$prefacture}',yusage = '{$yusage}',fax = '{$fax}', statustime = '{$dte}',cname = '{$cname}',cmob = '{$cmob}' where y_id = {$y_id}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>