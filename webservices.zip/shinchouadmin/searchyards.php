<?php
header("Content-Type: application/json");

require('db_con.php');

$name = $_POST['name'];
$city = $_POST['city'];
$country = $_POST['country'];
$pos = $_POST['pos'];
$email = $_POST['email'];
$status = $_POST['status'];

if($name == 'undefined')
	$name = '';

if($city == 'undefined')
	$city = '';

if($country == 'undefined')
	$country = '';

if($email == 'undefined')
	$email = '';

if($pos == 'undefined')
	$pos = '';

if($status == 'undefined')
	$status = '';

$sql = "SELECT * from yard where name LIKE '%{$name}%' && city LIKE '%{$city}%' && country LIKE '%{$country}%' && pos LIKE '%{$pos}%' && email LIKE '%{$email}%' && status LIKE '%{$status}%'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["y_id"] = $row["y_id"];       	
$arr[$i]["name"] = $row["name"];
$arr[$i]["address"] = $row["address"];
$arr[$i]["billingaddress"] = $row["billingaddress"];
$arr[$i]["branch"] = $row["branch"];
$arr[$i]["city"] = $row["city"];
$arr[$i]["country"] = $row["country"];
$arr[$i]["pos"] = $row["pos"];
$arr[$i]["tel"] = $row["tel"];
$arr[$i]["fax"] = $row["fax"];
$arr[$i]["prefacture"] = $row["prefacture"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["statustime"] = $row["statustime"];
$arr[$i]["status"] = $row["status"];
	   
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>