<?php
header("Content-Type: application/json");

require('db_con.php');

$s_id = $_POST['s_id'];

$sql = "SELECT * from shipper where s_id = {$s_id}";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
      	
$arr["sname"] = $row["sname"];
$arr["cperson"] = $row["cperson"];
$arr["tel"] = $row["phone"];
$arr["mob"] = $row["mobile"];
$arr["fax"] = $row["fax"];
$arr["email"] = $row["email"];
$arr["statustime"] = $row["statustime"];

}

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>