<?php
header("Content-Type: application/json");

require('db_con.php');

$color = $_POST['color'];
$username = $_POST['username'];


	$sql = "update userauth set colorscheme = '{$color}' where username = '{$username}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>