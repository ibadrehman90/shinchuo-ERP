<?php
header("Content-Type: application/json");

require('db_con.php');

$s_id = $_POST['s_id'];
$sname = $_POST['sname'];
$cperson = $_POST['cperson'];
$tel = $_POST['tel'];
$mob = $_POST['mob'];
$fax = $_POST['fax'];
$email = $_POST['email'];
$dte = $_POST['dte'];


	$sql = "update shipper set sname = '{$sname}',cperson = '{$cperson}',email = '{$email}',phone = '{$tel}',mobile = '{$mob}',fax = '{$fax}', statustime = '{$dte}' where s_id = {$s_id}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>