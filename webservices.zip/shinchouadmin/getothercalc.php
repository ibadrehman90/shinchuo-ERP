<?php
header("Content-Type: application/json");

require('db_con.php');

$sql = "SELECT * from lccsetting where cname != 'Default' order by c_id DESC";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["c_id"] = $row["c_id"];       	
$arr[$i]["cname"] = $row["cname"];
$arr[$i]["agent"] = $row["agent"];
$arr[$i]["exchange"] = $row["exchange"];
$arr[$i]["gst"] = $row["gst"];
$arr[$i]["freight"] = $row["freight"];
$arr[$i]["statustime"] = $row["statustime"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>