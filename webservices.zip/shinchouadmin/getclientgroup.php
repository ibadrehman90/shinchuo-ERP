<?php
header("Content-Type: application/json");

require('db_con.php');

$user = $_POST["username"];

$sql = "SELECT * from clientgroup where salesuser = '{$user}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["g_id"] = $row["g_id"];       	
$arr[$i]["gname"] = $row["gname"];
$arr[$i]["emails"] = $row["emails"];
$arr[$i]["status"] = $row["status"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>