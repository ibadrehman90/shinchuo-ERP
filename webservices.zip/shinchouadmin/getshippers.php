<?php
header("Content-Type: application/json");

require('db_con.php');

$sql = "SELECT * from shipper";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["s_id"] = $row["s_id"];       	
$arr[$i]["sname"] = $row["sname"];
$arr[$i]["cperson"] = $row["cperson"];
$arr[$i]["tel"] = $row["phone"];
$arr[$i]["mob"] = $row["mobile"];
$arr[$i]["fax"] = $row["fax"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["statustime"] = $row["statustime"];
$arr[$i]["status"] = $row["status"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>