<?php
header("Content-Type: application/json");

require('db_con.php');

$sno = $_POST['sno'];
$status = $_POST['status'];


	$sql = "update lccrequests set adminstatus = '{$status}' where sno = '{$sno}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>