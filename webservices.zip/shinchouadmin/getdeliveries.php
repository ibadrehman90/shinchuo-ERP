<?php
header("Content-Type: application/json");

require('db_con.php');


$sql = "SELECT * FROM `delivery` inner join transport on delivery.tid = transport.s_id inner join auction on delivery.aucid = auction.a_id";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["deliveryno"] = $row["deliveryno"];
$arr[$i]["deliverydate"] = $row["deliverydate"];
$arr[$i]["aname"] = $row["aname"];
$arr[$i]["sname"] = $row["sname"];
$arr[$i]["trackingno"] = $row["trackingno"];
$arr[$i]["timeslot"] = $row["timeslot"]; 
$arr[$i]["remark"] = $row["remark"];       	
$arr[$i]["inputby"] = $row["inputby"];
$arr[$i]["inputdate"] = $row["inputdate"];
$arr[$i]["inputtime"] = $row["inputtime"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>