<?php
header("Content-Type: application/json");

require('db_con.php');

$sql = "select orderno, orderdate, p_id, lot, make, model, year, client, prefix, serial, pickupdate, pickuploc, (SELECT name from yard where yard.y_id = orders.y_id) as dropoff, ostatus, currentloc from orderdetail inner JOIN orders on orders.orderno = orderdetail.ord_id inner join purchasedlist on orderdetail.p_id = purchasedlist.s_id order by p_id, orderdate";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["p_id"] = $row["p_id"];
$arr[$i]["serial"] = $row["serial"];
$arr[$i]["lot"] = $row["lot"];
$arr[$i]["make"] = $row["make"]; 
$arr[$i]["model"] = $row["model"];       	
$arr[$i]["year"] = $row["year"];
$arr[$i]["prefix"] = $row["prefix"];
$arr[$i]["client"] = $row["client"];
$arr[$i]["pickupdate"] = $row["pickupdate"];
$arr[$i]["pickuploc"] = $row["pickuploc"];
$arr[$i]["dropoff"] = $row["dropoff"];
$arr[$i]["ostatus"] = $row["ostatus"];
$arr[$i]["orderno"] = $row["orderno"];
$arr[$i]["orderdate"] = $row["orderdate"];
$arr[$i]["currentloc"] = $row["currentloc"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>