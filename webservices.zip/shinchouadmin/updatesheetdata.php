<?php
header("Content-Type: application/json");
require('db_con.php');

$prodid = $_POST['prodid'];
$oldurl = $_POST['oldurl'];
$newurl = $_POST['newurl'];

$sql = "SELECT * from productimages_temp where prodid = '{$prodid}'";

$result = $conn->query($sql);

$cid = false;

 while($row = $result->fetch_assoc()) {	
	
	$cid = true;		   
 }
 
 if($cid == false)
 {

	$sql = "insert into productimages_temp(prodid, oldurl, sheeturl) values('{$prodid}','{$oldurl}','{$newurl}');";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 
		
 }
 else
 {
	$sql = "update productimages_temp set sheeturl = '{$newurl}' where prodid = '{$prodid}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}
 }

$conn->close();  
	
echo json_encode($response);
	 
	
?>