<?php
header("Content-Type: application/json");

require('db_con.php');
$v_id = $_POST['v_id'];
$bno = $_POST['bno'];
$sname = $_POST['sname'];
$voyage = $_POST['voyage'];
$cut = $_POST['cut'];
$cyopen = $_POST['cyopen'];
$etd = $_POST['etd'];
$eta = $_POST['eta'];
$v_from = $_POST['v_from'];
$v_to = $_POST['v_to'];
$reserved = $_POST['reserved'];
$agent = $_POST['agent'];
$carrier = $_POST['carrier'];
$dte = $_POST['dte'];


	$sql = "update vessel set bno='{$bno}',sname = '{$sname}',voyage = '{$voyage}',cut = '{$cut}',cyopen = '{$cyopen}',etd = '{$etd}',eta = '{$eta}',v_from = '{$v_from}',v_to = '{$v_to}',reserved = '{$reserved}',agent = '{$agent}',carrier = '{$carrier}',statustime = '{$dte}' where v_id = {$v_id}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>