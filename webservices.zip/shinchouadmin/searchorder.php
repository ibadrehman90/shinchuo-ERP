<?php
header("Content-Type: application/json");

require('db_con.php');

$orderno = $_POST["orderno"];
$client = $_POST["client"];
$dst = $_POST["dst"];
$auction = $_POST["auction"];
$adate = $_POST["adate"];
$pos = $_POST["pos"];
$dai = $_POST["dai"];
$lot = $_POST["lot"];
$prefix = $_POST["prefix"];
$make = $_POST["make"];
$model = $_POST["model"];
$noplate = $_POST["noplate"];
$fudosha = $_POST["fudosha"];
$yard = $_POST["yard"];
$nocut = $_POST["nocut"];

if($client == 'undefined')       {$client = '';}
if($dst == 'undefined')          {$dst    = '';}
if($auction == 'undefined')      {$auction = '';}
if($adate == 'undefined')        {$adate  = '';}
if($pos == 'undefined')          {$pos    = '';}
if($dai == 'undefined')          {$dai    = '';}
if($lot == 'undefined')          {$lot    = '';}
if($prefix == 'undefined')       {$prefix = '';}
if($make == 'undefined')         {$make   = '';}
if($model == 'undefined')        {$model  = '';}
if($noplate == 'undefined')      {$noplate = '';}
if($fudosha == 'undefined')      {$fudosha = '';}
if($yard == 'undefined')  {$yard = '';}
if($nocut == 'undefined')    {$nocut = '';}

$sql = "SELECT * FROM orderdetail inner join purchasedlist on orderdetail.p_id = purchasedlist.s_id where ord_id = '{$orderno}' AND client LIKE '%{$client}%' AND dst LIKE '%{$dst}%' AND auction LIKE '%{$auction}%' AND adate LIKE '%{$adate}%' AND pos LIKE '%{$pos}%' AND dai LIKE '%{$dai}%' AND lot LIKE '%{$lot}%' AND prefix LIKE '%{$prefix}%' AND make LIKE '%{$make}%' AND model LIKE '%{$model}%' AND noplate LIKE '%{$noplate}%' AND fudosha LIKE '%{$fudosha}%' AND y_id LIKE '%{$yard}%' AND nocut LIKE '%{$nocut}%'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["s_id"] = $row["s_id"];
$arr[$i]["o_id"] = $row["o_id"]; 
$arr[$i]["prodid"] = $row["prodid"];       	
$arr[$i]["s_code"] = $row["s_code"];
$arr[$i]["client"] = $row["client"];
$arr[$i]["dst"] = $row["dst"];
$arr[$i]["auction"] = $row["auction"];
$arr[$i]["adate"] = $row["adate"];
$arr[$i]["pos"] = $row["pos"];
$arr[$i]["dai"] = $row["dai"];
$arr[$i]["lot"] = $row["lot"];
$arr[$i]["prefix"] = $row["prefix"];
$arr[$i]["serial"] = $row["serial"];
$arr[$i]["make"] = $row["make"];
$arr[$i]["model"] = $row["model"];
$arr[$i]["year"] = $row["year"];
$arr[$i]["bidprice"] = $row["bidprice"];
$arr[$i]["aucfee"] = $row["aucfee"];
$arr[$i]["exportcharge"] = $row["exportcharge"];
$arr[$i]["noplate"] = $row["noplate"];
$arr[$i]["plateserial"] = $row["plateserial"];
$arr[$i]["shaken"] = $row["shaken"];
$arr[$i]["fudosha"] = $row["fudosha"];
$arr[$i]["transmission"] = $row["transmission"];
$arr[$i]["enginecc"] = $row["enginecc"];
$arr[$i]["mileage"] = $row["mileage"];
$arr[$i]["color"] = $row["color"];
$arr[$i]["colorcode"] = $row["colorcode"];
$arr[$i]["buyingcom"] = $row["buyingcom"];
$arr[$i]["buyer"] = $row["buyer"];
$arr[$i]["remark"] = $row["remark"];
$arr[$i]["landedvalue"] = $row["landedvalue"];
$arr[$i]["soldprice"] = $row["soldprice"];
$arr[$i]["status"] = $row["status"];
$arr[$i]["y_id"] = $row["y_id"];
$arr[$i]["remarks"] = $row["remarks"];
$arr[$i]["nocut"] = $row["nocut"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>