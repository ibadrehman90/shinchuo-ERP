<?php
header("Content-Type: application/json");

require('db_con.php');

$bname = $_POST['bname'];
$username = $_POST['username'];
$mob = $_POST['mob'];
$email = $_POST['email'];
$role = $_POST['role'];

$sql = "select email from userauth where email = '{$email}' AND username != '{$username}'  AND role = '{$role}'";

$result = $conn->query($sql);

$i = 0;

while($row = $result->fetch_assoc()) {
 	$i++;     	
}

if($i == 0)
{

	$sql = "update userauth set name = '{$bname}',email = '{$email}',mobile = '{$mob}' where username = '{$username}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 

}
else
{
	$response['Status'] = "Exist";
}

$conn->close();  
	
echo json_encode($response);
	 
	
?>