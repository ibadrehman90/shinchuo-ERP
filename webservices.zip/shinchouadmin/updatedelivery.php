<?php
header("Content-Type: application/json");

require('db_con.php');

$remark = $_POST['remark'];
$deliveryno = $_POST['deliveryno'];
$deliverydate = $_POST['deliverydate'];
$trackingno = $_POST['trackingno'];
$timeslot = $_POST['timeslot'];
$tcomp = $_POST['tcomp'];
$acomp = $_POST['acomp'];


	$sql = "update delivery set remark = '{$remark}',timeslot = '{$timeslot}', deliverydate = '{$deliverydate}', trackingno = '{$trackingno}', tid = '{$tcomp}', aucid = '{$acomp}' where deliveryno = '{$deliveryno}'";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>