<?php
header("Content-Type: application/json");

require('db_con.php');

$orderno = $_POST['orderno'];

$sql = "SELECT * FROM orders inner join transport on orders.tcompany = transport.s_id where orderno = '{$orderno}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["orderno"] = $row["orderno"];
$arr[$i]["orderdate"] = $row["orderdate"];
$arr[$i]["pickupdate"] = $row["pickupdate"];
$arr[$i]["btnselect"] = $row["btnselect"];
$arr[$i]["dropoffdate"] = $row["dropoffdate"];
$arr[$i]["status"] = $row["ostatus"];
$arr[$i]["y_id"] = $row["y_id"];
$arr[$i]["s_id"] = $row["s_id"]; 
$arr[$i]["sname"] = $row["sname"];       	
$arr[$i]["cperson"] = $row["cperson"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["mob"] = $row["mobile"];
$arr[$i]["fax"] = $row["fax"];
$arr[$i]["tel"] = $row["phone"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>