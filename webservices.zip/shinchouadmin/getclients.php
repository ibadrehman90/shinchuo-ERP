<?php
header("Content-Type: application/json");

require('db_con.php');

$role = $_POST['role'];
$salesuser = $_POST['salesuser'];

if($role == 'admin')
$sql = "SELECT * from userauth where role = 'client'";

else
$sql = "SELECT * from userauth where role = 'client' AND salesuser = '{$salesuser}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["username"] = $row["username"];       	
$arr[$i]["email"] = $row["email"];
$arr[$i]["bname"] = $row["name"];
$arr[$i]["city"] = $row["city"];
$arr[$i]["country"] = $row["country"];
$arr[$i]["mob"] = $row["mobile"];
$arr[$i]["company"] = $row["company"];
$arr[$i]["port"] = $row["port"];
$arr[$i]["dor"] = $row["dor"];
$arr[$i]["llogin"] = $row["llogin"];
$arr[$i]["calculator"] = $row["calculator"];
$arr[$i]["salesuser"] = $row["salesuser"];
$arr[$i]["currency"] = $row["currency"];
$arr[$i]["address"] = $row["address"];
$arr[$i]["showlcc"] = $row["showlcc"];
$arr[$i]["status"] = $row["status"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>