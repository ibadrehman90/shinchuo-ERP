<?php
header("Content-Type: application/json");

require('db_con.php');

$field = $_POST['field'];
$val = $_POST['value'];
$oid = $_POST['oid'];


	$sql = "update orders set {$field} = '{$val}' where orderno = '{$oid}'";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>