<?php
header("Content-Type: application/json");

require('db_con.php');

$username = $_POST['username'];
$status = $_POST['status'];


	$sql = "update userauth set status = '{$status}' where username = '{$username}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>