<?php
header("Content-Type: application/json");

require('db_con.php');

$did = $_POST['did'];
$noplate = $_POST['noplate'];
$book = $_POST['book'];
$navicd = $_POST['navicd'];
$naviremote = $_POST['naviremote'];
$nutlock = $_POST['nutlock'];
$knob = $_POST['knob'];
$other = $_POST['other'];
$tohon = $_POST['tohon'];
$crkeys = $_POST['crkeys'];
$carremotekey = $_POST['carremotekey'];
$sd = $_POST['sd'];
$mnote = $_POST['mnote'];
$monitor = $_POST['monitor'];



	$sql = "update deliverydetail set noplate = {$noplate}, book = {$book}, navicd = {$navicd}, naviremote = {$naviremote}, nutlock = {$nutlock}, knob = {$knob}, other = {$other}, tohon = {$tohon}, crkeys = {$crkeys}, carremotekey = {$carremotekey}, sd = {$sd}, mnote = {$mnote}, monitor = {$monitor} where d_id = {$did}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

$conn->close();  
	
echo json_encode($response);
	 
	
?>