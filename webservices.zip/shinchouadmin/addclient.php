<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$username = $_POST['username'];
$bname = $_POST['bname'];
$port = $_POST['port'];
$pass = $_POST['pass'];
$mob = $_POST['mob'];
$country = $_POST['country'];
$email = $_POST['email'];
$city = $_POST['city'];
$company = $_POST['company'];
$address = $_POST['address'];
$salesuser = $_POST['salesuser'];

$sql = "select email from userauth where email = '{$email}'";

$result = $conn->query($sql);

$i = 0;

while($row = $result->fetch_assoc()) {
 	$i++;     	
}

if($i == 0)
{

	$sql = "insert into userauth(username,email,password,name,city,country,mobile,port,company,address,calculator,currency,showlcc,role,salesuser,status) values('{$username}','{$email}','{$pass}','{$bname}','{$city}','{$country}','{$mob}','{$port}','{$company}','{$address}','Default','JPY','1','client','{$salesuser}','1'); insert into userview values('{$username}',1,1,1,1,1,1,1,1,1,1,1,1,1,1,1)";

	if ($conn->multi_query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
		
		if (strpos($response['Status'], 'PRIMARY') !== false) {
			$response['Status'] = 'UserExist';
		}
	}

}
else
{
	$response['Status'] = "Exist";
}

}

$conn->close();  

echo json_encode($response);
?>