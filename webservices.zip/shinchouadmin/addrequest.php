<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$username = $_POST['username'];
$agent = $_POST['agent'];
$exchange = $_POST['exchange'];
$freight = $_POST['freight'];
$dte = $_POST['dte'];


	$sql = "insert into lccrequests(client, requestby, agentfee, exchange, frieght,statustime,adminstatus,clientstatus) values('{$username}','{$username}','{$agent}','{$exchange}','{$freight}','{$dte}','0','0')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

}

$conn->close();  

echo json_encode($response);
?>