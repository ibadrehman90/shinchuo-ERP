<?php
header("Content-Type: application/json");

require('db_con.php');

$portid = $_POST['portid'];
$status = $_POST['status'];


	$sql = "update ports set approval = '{$status}' where port_id = '{$portid}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>