<?php
header("Content-Type: application/json");

require('db_con.php');

$a_id = $_POST['a_id'];
$aname = $_POST['aname'];
$pos = $_POST['pos'];
$tel = $_POST['tel'];
$cname = $_POST['cname'];
$fax = $_POST['fax'];
$email = $_POST['email'];
$dte = $_POST['dte'];


	$sql = "update auction set aname = '{$aname}',pos = '{$pos}',email = '{$email}',tel = '{$tel}',cname = '{$cname}',fax = '{$fax}', statustime = '{$dte}' where a_id = {$a_id}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>