<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$email = $_POST['email'];
$auction = $_POST['auction'];
$fromdate = $_POST['fromdate'];
$sday = $_POST['sday'];
$dte = $_POST['dte'];

	$sql = "insert into assignauction(b_email,day,auction,fromdate,statustime,status) values('{$email}','{$sday}','{$auction}','{$fromdate}','{$dte}',1)";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

}

$conn->close();  

echo json_encode($response);
?>