<?php
header("Content-Type: application/json");

require('db_con.php');

$tab = $_POST['tab'];
$cat = $_POST['cat'];
$val = $_POST['val'];
$yardid = $_POST['yardid'];


	$sql = "insert into {$tab}({$cat}, yardid) values('{$val}','{$yardid}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>