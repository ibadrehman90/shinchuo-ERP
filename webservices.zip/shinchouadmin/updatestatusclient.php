<?php
header("Content-Type: application/json");

require('db_con.php');

$email = $_POST['email'];
$status = $_POST['status'];


	$sql = "update userauth set status = '{$status}' where username = '{$email}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>