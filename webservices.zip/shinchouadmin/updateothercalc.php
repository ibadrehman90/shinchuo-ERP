<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$cname = $_POST['cname'];
$agent = $_POST['agent'];
$gst = $_POST['gst'];
$exchange = $_POST['exchange'];
$freight = $_POST['freight'];
$dte = $_POST['dte'];

$id = 0;

$sql = "SELECT MAX(c_id) as mxy FROM `lccsetting` WHERE cname = '{$cname}' ORDER BY cname ASC";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
      $id = $row['mxy'];	
} 

	$sql = "insert into lccsetting(cname,agent,gst,exchange,freight,statustime) values('{$cname}','{$agent}','{$gst}','{$exchange}','{$freight}','{$dte}');";
	
	if($id != 0)
	$sql .= "update lccsetting set statustime = '{$dte}' where c_id = '{$id}'";

	if ($conn->multi_query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

}

$conn->close();  

echo json_encode($response);
?>