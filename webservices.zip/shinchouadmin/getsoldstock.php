<?php
header("Content-Type: application/json");

require('db_con.php');

$user = $_POST['userid'];
$role = $_POST['role'];
$sql = '';

if($role == 'salesuser')
{
$sql = "SELECT *,(select images from productdetail where id = purchasedlist.prodid) as pimages,(select newurl from productimages_temp where prodid = purchasedlist.prodid) as newimages,(select sheeturl from productimages_temp where prodid = purchasedlist.prodid) as newsheet from purchasedlist inner join stocksoldlist on purchasedlist.s_id = stocksoldlist.s_id where client = '{$user}'";
}
else if($role == 'admin')
{
$sql = "SELECT *,(select images from productdetail where id = purchasedlist.prodid) as pimages,(select newurl from productimages_temp where prodid = purchasedlist.prodid) as newimages,(select sheeturl from productimages_temp where prodid = purchasedlist.prodid) as newsheet from purchasedlist inner join stocksoldlist on purchasedlist.s_id = stocksoldlist.s_id";    
}

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["s_id"] = $row["s_id"]; 
$arr[$i]["prodid"] = $row["prodid"];
$arr[$i]["images"] = $row["pimages"];
$arr[$i]["cimages"] = $row["images"];
$arr[$i]["newimages"] = $row["newimages"];
$arr[$i]["newsheet"] = $row["newsheet"];
$arr[$i]["client"] = $row["client"];
$arr[$i]["auction"] = $row["auction"];
$arr[$i]["adate"] = $row["adate"];
$arr[$i]["lot"] = $row["lot"];
$arr[$i]["prefix"] = $row["prefix"];
$arr[$i]["make"] = $row["make"];
$arr[$i]["model"] = $row["model"];
$arr[$i]["year"] = $row["year"];
$arr[$i]["bidprice"] = $row["bidprice"];
$arr[$i]["transmission"] = $row["transmission"];
$arr[$i]["enginecc"] = $row["enginecc"];
$arr[$i]["mileage"] = $row["mileage"];
$arr[$i]["color"] = $row["color"];
$arr[$i]["remark"] = $row["remark"];
$arr[$i]["remarks"] = $row["remarks"];
$arr[$i]["landedvalue"] = $row["landedvalue"];
$arr[$i]["stocksold"] = $row["stocksold"];
$arr[$i]["soldto"] = $row["soldto"];
$arr[$i]["soldon"] = $row["soldon"];
$arr[$i]["soldprice"] = $row["soldprice"];
$arr[$i]["soldid"] = $row["sold_id"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>