<?php
header("Content-Type: application/json");

require('db_con.php');

$client = $_POST['client'];
$lot = $_POST['lot'];
$port = $_POST['port'];
$country = $_POST['country'];
$yard = $_POST['yard'];
$auction = $_POST['auction'];
$serial = $_POST['serial'];


if($client == 'undefined')
	$client = '';

if($lot == 'undefined')
	$lot = '';

if($port == 'undefined')
	$port = '';

if($country == 'undefined')
	$country = '';

if($yard == 'undefined')
	$yard = '';
	
if($auction == 'undefined')
	$auction = '';
	
if($serial == 'undefined')
	$serial = '';

$sql = "select p_id,auction, adate, dai, serial, s_code, plateserial,lot, make, model, year, prefix, client, port, country, yardname from (select p_id,auction, adate, dai, serial, s_code, plateserial,lot, make, model, year, prefix, client, (select port from userauth where username = client) as port, (select country from userauth where username = client) as country, (select name from yard where yard.y_id = orders.y_id) as yardname from orders inner join orderdetail on orderdetail.ord_id = orders.orderno inner join purchasedlist on orderdetail.p_id = purchasedlist.s_id where orders.ostatus = 1 AND orderdetail.status = 0) t1 where client LIKE '%{$client}%' AND lot LIKE '%{$lot}%' AND port LIKE '%{$port}%' AND yardname LIKE '%{$yard}%' AND country LIKE '%{$country}%' AND auction LIKE '%{$auction}%' AND serial LIKE '%$serial%'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["p_id"] = $row["p_id"];
$arr[$i]["auction"] = $row["auction"];
$arr[$i]["adate"] = $row["adate"];
$arr[$i]["dai"] = $row["dai"];
$arr[$i]["serial"] = $row["serial"];
$arr[$i]["s_code"] = $row["s_code"];
$arr[$i]["plateserial"] = $row["plateserial"];
$arr[$i]["lot"] = $row["lot"];
$arr[$i]["make"] = $row["make"]; 
$arr[$i]["model"] = $row["model"];       	
$arr[$i]["year"] = $row["year"];
$arr[$i]["prefix"] = $row["prefix"];
$arr[$i]["client"] = $row["client"];
$arr[$i]["port"] = $row["port"];
$arr[$i]["country"] = $row["country"];
$arr[$i]["yardname"] = $row["yardname"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>