<?php
header("Content-Type: application/json");

require('db_con.php');

$orderno = $_POST['orderno'];
$ofrom = $_POST['ofrom'];
$oto = $_POST['oto'];
$trans = $_POST['trans'];
$pick = $_POST['pick'];
$drop = $_POST['drop'];


if($orderno == 'undefined')
	$orderno = '';

if($ofrom == 'undefined')
	$ofrom = '';

if($oto == 'undefined')
	$oto = '';

if($trans == 'undefined')
	$trans = '';

if($pick == 'undefined')
	$pick = '';

if($drop == 'undefined')
	$drop = '';

$sql = "SELECT * from (SELECT * from (SELECT ord_id,GROUP_CONCAT(auction) as auction, count(*) as units from purchasedlist inner join orderdetail on purchasedlist.s_id = orderdetail.p_id group by ord_id) as t1 LEFT JOIN (SELECT orderno, orderdate, ostatus, completedin, dropoffdate, orders.y_id, sname, phone, (select name from yard where yard.y_id = orders.y_id) as yardname FROM orders LEFT JOIN transport on transport.s_id = orders.tcompany) as t2 on t1.ord_id = t2.orderno where t2.orderdate < '". date("m/d/Y") . "') as t3 where t3.orderno LIKE '%{$orderno}%' && t3.orderdate >= '{$ofrom}' && t3.orderdate <= '{$oto}' && t3.sname LIKE '%{$trans}%' && t3.auction LIKE '%{$pick}%' && t3.yardname LIKE '%{$drop}%'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["orderno"] = $row["orderno"];
$arr[$i]["orderdate"] = $row["orderdate"]; 
$arr[$i]["sname"] = $row["sname"];       	
$arr[$i]["tel"] = $row["phone"];
$arr[$i]["yname"] = $row["yardname"];
$arr[$i]["aucname"] = $row["auction"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>