<?php
header("Content-Type: application/json");

require('db_con.php');

$country = $_POST['country'];
$make = $_POST['make'];

$sql = "SELECT * from custommodel where country = '{$country}' AND make = '{$make}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["cid"] = $row["cid"];       	
$arr[$i]["country"] = $row["country"];
$arr[$i]["make"] = $row["make"];
$arr[$i]["modellist"] = $row["modellist"];
$arr[$i]["otherlist"] = $row["otherlist"];
	   
	   $i++;
}

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>