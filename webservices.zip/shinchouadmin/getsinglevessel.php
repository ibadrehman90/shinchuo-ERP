<?php
header("Content-Type: application/json");

require('db_con.php');

$v_id = $_POST['v_id'];

$sql = "SELECT * from vessel where v_id = {$v_id}";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
      	
$arr["bno"] = $row["bno"];
$arr["sname"] = $row["sname"];
$arr["voyage"] = $row["voyage"];
$arr["cut"] = $row["cut"];
$arr["cyopen"] = $row["cyopen"];
$arr["etd"] = $row["etd"];
$arr["eta"] = $row["eta"];
$arr["v_from"] = $row["v_from"];
$arr["v_to"] = $row["v_to"];
$arr["reserved"] = $row["reserved"];
$arr["agent"] = $row["agent"];
$arr["carrier"] = $row["carrier"];
$arr["statustime"] = $row["statustime"];

}

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>