<?php
header("Content-Type: application/json");

require('db_con.php');

$userid = $_GET['username'];

$sql = "SELECT * from userauth where username = '{$userid}'";

$result = $conn->query($sql);

$response["Status"] = "null";

 while($row = $result->fetch_assoc()) {
        		
	$response["name"] = $row["name"];
	$response["rolename"] = $row["role"];
	$response["pimg"] = $row["profileimg"];
	$response["colorscheme"] = $row["colorscheme"];
	$response["Status"] = "Done";
}

$conn->close();	

echo json_encode($response);
	 
	
?>