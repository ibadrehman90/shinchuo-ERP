<?php
header("Content-Type: application/json");

require('db_con.php');

$y_id = $_POST['y_id'];

$sql = "SELECT * from yardcontactpersons where yardid = {$y_id}";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
      	
$arr[$i]["r_id"] = $row["r_id"];       	
$arr[$i]["repname"] = $row["repname"];
$arr[$i]["mob"] = $row["mob"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["yardid"] = $row["yardid"];
$i++;
}

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>