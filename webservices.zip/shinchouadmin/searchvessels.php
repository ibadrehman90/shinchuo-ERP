<?php
header("Content-Type: application/json");

require('db_con.php');


$bno = $_POST['bno'];
$sname = $_POST['sname'];
$voyage = $_POST['voyage'];
$cut = $_POST['cut'];
$cyopen = $_POST['cyopen'];
$etd = $_POST['etd'];
$eta = $_POST['eta'];
$v_from = $_POST['v_from'];
$v_to = $_POST['v_to'];
$reserved = $_POST['reserved'];
$agent = $_POST['agent'];
$carrier = $_POST['carrier'];

if($bno == 'undefined')
	$bno = '';

if($sname == 'undefined')
	$sname = '';

if($voyage == 'undefined')
	$voyage = '';

if($cut == 'undefined')
	$cut = '';

if($cyopen == 'undefined')
	$cyopen = '';

if($etd == 'undefined')
	$etd = '';

if($eta == 'undefined')
	$eta = '';

if($v_from == 'undefined')
	$v_from = '';

if($v_to == 'undefined')
	$v_to = '';

if($reserved == 'undefined')
	$reserved = '';

if($agent == 'undefined')
	$agent = '';

if($carrier == 'undefined')
	$carrier = '';

$sql = "SELECT * from vessel where bno LIKE '%{$bno}%' && sname LIKE '%{$sname}%' && voyage LIKE '%{$voyage}%' && cut LIKE '%{$cut}%' && cyopen LIKE '%{$cyopen}%' && etd LIKE '%{$etd}%' && eta LIKE '%{$eta}%' && v_from LIKE '%{$v_from}%' && v_to LIKE '%{$v_to}%' && reserved LIKE '%{$reserved}%' && agent LIKE '%{$agent}%' && carrier LIKE '%{$carrier}%'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["v_id"] = $row["v_id"];       	
$arr[$i]["bno"] = $row["bno"];
$arr[$i]["sname"] = $row["sname"];
$arr[$i]["voyage"] = $row["voyage"];
$arr[$i]["cut"] = $row["cut"];
$arr[$i]["cyopen"] = $row["cyopen"];
$arr[$i]["etd"] = $row["etd"];
$arr[$i]["eta"] = $row["eta"];
$arr[$i]["v_from"] = $row["v_from"];
$arr[$i]["v_to"] = $row["v_to"];
$arr[$i]["reserved"] = $row["reserved"];
$arr[$i]["agent"] = $row["agent"];
$arr[$i]["carrier"] = $row["carrier"];
$arr[$i]["statustime"] = $row["statustime"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>