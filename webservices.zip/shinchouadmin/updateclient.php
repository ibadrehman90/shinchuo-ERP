<?php
header("Content-Type: application/json");

require('db_con.php');

$email = $_POST['email'];
$bname = $_POST['bname'];
$port = $_POST['port'];
$city = $_POST['city'];
$country = $_POST['country'];
$company = $_POST['company'];
$address = $_POST['address'];
$mob = $_POST['mob'];



	$sql = "update userauth set name = '{$bname}', port = '{$port}', city = '{$city}', country = '{$country}', company = '{$company}', address = '{$address}', mobile = '{$mob}' where username = '{$email}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

$conn->close();  
	
echo json_encode($response);
	 
	
?>