<?php
header("Content-Type: application/json");

require('db_con.php');

$cat = $_POST['cat'];
$val = $_POST['val'];
$sid = $_POST['sid'];


	$sql = "update purchasedlist set {$cat} = '{$val}' where s_id = '{$sid}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>