<?php
header("Content-Type: application/json");

require('db_con.php');

$a_id = $_POST['a_id'];

$sql = "SELECT * from auction where a_id = {$a_id}";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
      	
$arr["a_id"] = $row["a_id"];       	
$arr["aname"] = $row["aname"];
$arr["pos"] = $row["pos"];
$arr["tel"] = $row["tel"];
$arr["fax"] = $row["fax"];
$arr["cname"] = $row["cname"];
$arr["email"] = $row["email"];
$arr["statustime"] = $row["statustime"];

}

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>