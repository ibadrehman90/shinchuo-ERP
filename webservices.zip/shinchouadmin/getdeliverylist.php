<?php
header("Content-Type: application/json");

require('db_con.php');

$orderno = $_POST['orderno'];

$sql = "select * from (select * from (select o_id,p_id,auction, adate, dai, serial, s_code, plateserial,lot, make, model, year, prefix, client, (select port from userauth where username = client) as port, (select country from userauth where username = client) as country, (select name from yard where yard.y_id = orders.y_id) as yardname from orders inner join orderdetail on orderdetail.ord_id = orders.orderno inner join purchasedlist on orderdetail.p_id = purchasedlist.s_id where orders.ostatus = 1) as tt1 where o_id IN (select MAX(o_id) from (select o_id,p_id,auction, adate, dai, serial, s_code, plateserial,lot, make, model, year, prefix, client, (select port from userauth where username = client) as port, (select country from userauth where username = client) as country, (select name from yard where yard.y_id = orders.y_id) as yardname from orders inner join orderdetail on orderdetail.ord_id = orders.orderno inner join purchasedlist on orderdetail.p_id = purchasedlist.s_id where orders.ostatus = 1) as t2 group by p_id)) as tab1 inner join deliverydetail on tab1.p_id = deliverydetail.sp_id where deliveryno = '{$orderno}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["p_id"] = $row["p_id"];
$arr[$i]["d_id"] = $row["d_id"];
$arr[$i]["auction"] = $row["auction"];
$arr[$i]["adate"] = $row["adate"];
$arr[$i]["dai"] = $row["dai"];
$arr[$i]["serial"] = $row["serial"];
$arr[$i]["s_code"] = $row["s_code"];
$arr[$i]["plateserial"] = $row["plateserial"];
$arr[$i]["lot"] = $row["lot"];
$arr[$i]["make"] = $row["make"]; 
$arr[$i]["model"] = $row["model"];       	
$arr[$i]["year"] = $row["year"];
$arr[$i]["prefix"] = $row["prefix"];
$arr[$i]["client"] = $row["client"];
$arr[$i]["port"] = $row["port"];
$arr[$i]["country"] = $row["country"];
$arr[$i]["yardname"] = $row["yardname"];

$arr[$i]["noplate"] = $row['noplate'];
$arr[$i]["book"] = $row['book'];
$arr[$i]["navicd"] = $row['navicd'];
$arr[$i]["naviremote"] = $row['naviremote'];
$arr[$i]["nutlock"] = $row['nutlock'];
$arr[$i]["knob"] = $row['knob'];
$arr[$i]["other"] = $row['other'];
$arr[$i]["tohon"] = $row['tohon'];
$arr[$i]["crkeys"] = $row['crkeys'];
$arr[$i]["carremotekey"] = $row['carremotekey'];
$arr[$i]["sd"] = $row['sd'];
$arr[$i]["mnote"] = $row['mnote'];
$arr[$i]["monitor"] = $row['monitor'];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>