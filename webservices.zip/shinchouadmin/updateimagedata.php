<?php
header("Content-Type: application/json");
require('db_con.php');

$prodid = $_POST['prodid'];
$newurl = $_POST['newurl'];

	$sql = "update purchasedlist set images = '{$newurl}' where prodid = '{$prodid}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

$conn->close();  
	
echo json_encode($response);
	 
	
?>