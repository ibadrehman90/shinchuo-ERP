<?php
header("Content-Type: application/json");

require('db_con.php');

$bno = $_POST['bno'];
$sname = $_POST['sname'];
$voyage = $_POST['voyage'];
$cut = $_POST['cut'];
$cyopen = $_POST['cyopen'];
$etd = $_POST['etd'];
$eta = $_POST['eta'];
$v_from = $_POST['v_from'];
$v_to = $_POST['v_to'];
$reserved = $_POST['reserved'];
$agent = $_POST['agent'];
$carrier = $_POST['carrier'];
$dte = $_POST['dte'];


	$sql = "insert into vessel(bno,sname,voyage,cut,cyopen,etd,eta,v_from,v_to,reserved,agent,carrier,statustime) values('{$bno}','{$sname}','{$voyage}','{$cut}','{$cyopen}','{$etd}','{$eta}','{$v_from}','{$v_to}','{$reserved}','{$agent}','{$carrier}','{$dte}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>