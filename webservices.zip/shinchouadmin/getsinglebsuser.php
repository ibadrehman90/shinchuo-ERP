<?php
header("Content-Type: application/json");

require('db_con.php');

$username = $_POST['username'];

$sql = "SELECT * from userauth where username = '{$username}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
      	
$arr["username"] = $row["username"];       	
$arr["bname"] = $row["name"];
$arr["city"] = $row["city"];
$arr["country"] = $row["country"];
$arr["mob"] = $row["mobile"];
$arr["email"] = $row["email"];
$arr["status"] = $row["status"];
$arr["showlcc"] = $row["showlcc"];

}

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>