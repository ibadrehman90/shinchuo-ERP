<?php
header("Content-Type: application/json");

require('db_con.php');

$sql = "SELECT * from auction";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["a_id"] = $row["a_id"];       	
$arr[$i]["aname"] = $row["aname"];
$arr[$i]["pos"] = $row["pos"];
$arr[$i]["tel"] = $row["tel"];
$arr[$i]["fax"] = $row["fax"];
$arr[$i]["cname"] = $row["cname"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["statustime"] = $row["statustime"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>