<?php
header("Content-Type: application/json");

require('db_con.php');

$y_id = $_POST['y_id'];
$status = $_POST['status'];


	$sql = "update yard set status = '{$status}' where y_id = {$y_id}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>