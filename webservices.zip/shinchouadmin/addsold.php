<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$prodid = $_POST['id'];
$client = $_POST['client'];
$bidamt = $_POST['bidamt'];
$buyer = $_POST['buyer'];
$remark = $_POST['remark'];

	$sql = "insert into soldlist(prodid, client, soldprice, buyer, remark) values('{$prodid}','{$client}','{$bidamt}','{$buyer}','{$remark}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 

}

$conn->close();  

echo json_encode($response);
?>