<?php
header("Content-Type: application/json");

require('db_con.php');

$response['Status'] = '';

$sql = "select p_id, orderno, pickupdate, ostatus, currentloc from orders inner join orderdetail on orders.orderno = orderdetail.ord_id inner join purchasedlist on orderdetail.p_id = purchasedlist.s_id where ostatus = 0 AND pickupdate <= CURRENT_DATE AND currentloc != 'In Transit'";

$sql_up = '';

$result = $conn->query($sql);

while($row = $result->fetch_assoc()) {
    $pid = $row['p_id'];
    
    $sql_up .= "update purchasedlist set currentloc = 'In Transit' where s_id = '{$pid}';";
}


	if ($conn->multi_query($sql_up) === TRUE) {
		
		do
		{
			// Store first result set
			if ($result1=mysqli_store_result($conn)) {
			  // Fetch one and one row
			  while ($row1=mysqli_fetch_row($result1))
				{
				printf("%s\n",$row1[0]);
				}
			  // Free result set
			  mysqli_free_result($result1);
			  }
		}
		while (mysqli_next_result($conn));
		
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;		
	}

$conn->close();	

echo json_encode($response);
?>