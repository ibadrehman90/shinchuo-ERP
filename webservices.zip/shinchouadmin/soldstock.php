<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$sid = $_POST['sid'];
$samount = $_POST['samount'];
$soldto = $_POST['soldto'];
$soldon = $_POST['dte'];
$remark = $_POST['cmment'];

	$sql = "insert into stocksoldlist(s_id, soldprice, soldto, soldon, remarks) values('{$sid}','{$samount}','{$soldto}','{$soldon}','{$remark}'); update purchasedlist set stocksold = 1 where s_id = {$sid};";

	if ($conn->multi_query($sql) === TRUE) {
		
		do
		{
			// Store first result set
			if ($result1=mysqli_store_result($conn)) {
			  // Fetch one and one row
			  while ($row1=mysqli_fetch_row($result1))
				{
				printf("%s\n",$row1[0]);
				}
			  // Free result set
			  mysqli_free_result($result1);
			  }
		}
		while (mysqli_next_result($conn));
		
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;		
	}
}

$conn->close();  

echo json_encode($response);
?>