<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$orderno = $_POST['orderno'];
$ordlist = $_POST['ordlist'];
$orddate = $_POST['orddate'];
$pickupdate = $_POST['pickupdate'];
$btnselect = $_POST['btnselect'];

$ordlist = substr($ordlist,0,strlen($ordlist) - 1);
$ordlists = explode("|", $ordlist);

$finalordlists = '';

foreach ($ordlists as $value) {

    $auc = '';

if($btnselect == 0)
{
    $sqls = "select auction from purchasedlist where s_id = '{$value}'";
    
    $results = $conn->query($sqls);
    
    while($rows = $results->fetch_assoc()) {
     	     $auc = $rows['auction'];	
    }
    
    $finalordlists .= "insert into orderdetail(p_id,ord_id,pickuploc) values('{$value}','{$orderno}','{$auc}'); update purchasedlist set status = '1', currentloc = '{$auc}' where s_id = {$value};";
}
else if($btnselect == 1)
{
     $sqls = "select orders.y_id,(select name from yard where yard.y_id = orders.y_id) as yardname from orders inner join orderdetail on orders.orderno = orderdetail.ord_id where p_id = '{$value}'";
    
    $results = $conn->query($sqls);
    
    while($rows = $results->fetch_assoc()) {
     	     $auc = $rows['yardname'];	
    }
    
    $finalordlists .= "insert into orderdetail(p_id,ord_id,pickuploc) values('{$value}','{$orderno}','{$auc}');";
}
    
    
}

$sql = "select * from orders where orderno = '{$orderno}'";

$result = $conn->query($sql);

$i = 0;

while($row = $result->fetch_assoc()) {
 	$i++;     	
}

if($i == 0)
{

	$sql = "insert into orders(orderno, orderdate, tcompany, y_id, ostatus, completedin, dropoffdate, pickupdate, btnselect) values('{$orderno}','{$orddate}','','','N/A','N/A','N/A','{$pickupdate}','{$btnselect}');" . $finalordlists;

	if ($conn->multi_query($sql) === TRUE) {
		
		do
		{
			// Store first result set
			if ($result1=mysqli_store_result($conn)) {
			  // Fetch one and one row
			  while ($row1=mysqli_fetch_row($result1))
				{
				printf("%s\n",$row1[0]);
				}
			  // Free result set
			  mysqli_free_result($result1);
			  }
		}
		while (mysqli_next_result($conn));
		
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;		
	}
	
}
else
{
	$sql = $finalordlists;

	if ($conn->multi_query($sql) === TRUE) {
		
		do
		{
			// Store first result set
			if ($result1=mysqli_store_result($conn)) {
			  // Fetch one and one row
			  while ($row1=mysqli_fetch_row($result1))
				{
				printf("%s\n",$row1[0]);
				}
			  // Free result set
			  mysqli_free_result($result1);
			  }
		}
		while (mysqli_next_result($conn));
		
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;		
	}
}
}

$conn->close();  

echo json_encode($response);
?>