<?php
header("Content-Type: application/json");

require('db_con.php');

$sql = "SELECT * from yard order by status";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["y_id"] = $row["y_id"];       	
$arr[$i]["name"] = $row["name"];
$arr[$i]["address"] = $row["address"];
$arr[$i]["billingaddress"] = $row["billingaddress"];
$arr[$i]["branch"] = $row["branch"];
$arr[$i]["city"] = $row["city"];
$arr[$i]["country"] = $row["country"];
$arr[$i]["pos"] = $row["pos"];
$arr[$i]["tel"] = $row["tel"];
$arr[$i]["fax"] = $row["fax"];
$arr[$i]["prefacture"] = $row["prefacture"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["statustime"] = $row["statustime"];
$arr[$i]["status"] = $row["status"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>