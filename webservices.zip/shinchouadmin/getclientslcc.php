<?php
header("Content-Type: application/json");

require('db_con.php');

$salesuser = $_POST['salesuser'];

$sql = "select * from lccsetting inner join userauth on lccsetting.cname = userauth.calculator where lccsetting.c_id = (select MAX(c_id) from lccsetting where lccsetting.cname = userauth.calculator) AND userauth.salesuser = '{$salesuser}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {      	
$arr[$i]["username"] = $row["username"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["agentfee"] = $row["agent"];
$arr[$i]["gst"] = $row["gst"];
$arr[$i]["exchange"] = $row["exchange"];
$arr[$i]["freight"] = $row["freight"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>