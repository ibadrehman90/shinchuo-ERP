<?php
header("Content-Type: application/json");

require('db_con.php');

$email = $_POST['email'];
$cat = $_POST['cat'];
$status = $_POST['status'];


	$sql = "update userview set {$cat} = '{$status}' where client = '{$email}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

$conn->close();  
	
echo json_encode($response);
	 
	
?>