<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$prodid = $_POST['id'];
$client = $_POST['client'];
$auction = $_POST['auction'];
$adate = $_POST['adate'];
$make = $_POST['make'];
$model = $_POST['model'];
$year = $_POST['year'];
$lot = $_POST['lot'];
$chassis = $_POST['chassis'];
$serial = $_POST['serial'];
$bidamt = $_POST['bidamt'];
$trans = $_POST['trans'];
$engcc = $_POST['cc'];
$mileage = $_POST['mileage'];
$color = $_POST['color'];
$buyer = $_POST['buyer'];
$remark = $_POST['remark'];
$landed = $_POST['landed'];


$email = '';

    $subsql1 = "SELECT email from userauth where username = '{$client}'";

	$subresult1 = $conn->query($subsql1);

	while($row = $subresult1->fetch_assoc()) {			
	 $email = $row['email'];   		   
	}


$images = '';

$sqls = "SELECT images from productdetail where id = '{$prodid}'";

$results = $conn->query($sqls);

while($row = $results->fetch_assoc()) {	
	
	$images = $row['images'];	
	//$images = substr($images,0,strlen($images) - 1);
	//$newimages = explode("#",$images);
	//array_shift($newimages);
	//$images = join("#",$newimages);
}

if($serial == '')
$serial = 'N/A';

	$sql = "insert into purchasedlist(prodid, client, auction, adate, lot, prefix, serial, make, model, year, bidprice, transmission, enginecc, mileage, color, buyer, remark, landedvalue,s_code,dst,pos,dai,aucfee,exportcharge,noplate,plateserial,shaken,fudosha,colorcode,buyingcom,soldprice,showsellprice, images) values('{$prodid}','{$client}','{$auction}','{$adate}','{$lot}','{$chassis}','{$serial}','{$make}','{$model}','{$year}','{$bidamt}','{$trans}','{$engcc}','{$mileage}','{$color}','{$buyer}','{$remark}','{$landed}','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','1','{$images}')";

	
	 $sfr_user = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
  
  <title>Email Format</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  
 <style>
 h3{
 margin:5px;
 padding:10px;
 font-family: Calibri;
 }
 
 span
 {
	font-size:14px;
	color:#333;
 }
 </style>
  
 </head>
<body style="margin: 0; padding: 0;">
 <table align="center" cellpadding="0" cellspacing="0" style="border-collapse: collapse;">';

			
$sfr_user .= '<tr style="border-bottom:1px solid #999;text-align:center">
  <td colspan="2"><h3>CONGRATULATIONS! YOUR BID HAS WON!</h3></td>
 </tr>
<tr>
	<td style="width:25%; padding:10px;text-align:justify; border-right:1px solid #999;border-bottom:1px solid #999">
		<p>
		<b>' . $year . ' ' . $make . ' ' . $model . ' ' . $lot . '</b>
		<br/>
		Purchased Amount: ¥ '  . $bidamt . ' '  . $auction . ' '  . $mileage . 'km '  . $engcc . 'cc '  . $serial . ' '  . $trans . '
		</p>
	</td>
	<td style="width:75%;border-bottom:1px solid #999">
		<table>
			<tr>';
		
		$imgsplit = explode("#",$images);
		for($f = 0; $f < sizeof($imgsplit); $f++)
		{
			$sfr_user .= '<td style="25%"><img src="' . $imgsplit[$f] .'" height="100"/></td>';
			
			if($f == 4 || $f == 8)
			{
				$sfr_user .= '</tr><tr>';
			}			
		}

$sfr_user .='</tr></table>
	</td>
</tr>';

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

$sfr_user.= '
</table>
</body>
</html>';
	
	
	
	if ($conn->query($sql) === TRUE) {
		mail($email,"Your Bid Won",$sfr_user, $headers);
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 

}

$conn->close();  

echo json_encode($response);
?>