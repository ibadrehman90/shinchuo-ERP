<?php
header("Content-Type: application/json");

require('db_con.php');

$username = $_POST['username'];

$sql = "SELECT * from userauth where salesuser = '{$username}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
      	
$arr[$i]["user"] = $row["username"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["name"] = $row["name"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>