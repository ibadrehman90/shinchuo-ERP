<?php
header("Content-Type: application/json");

require('db_con.php');

$v_id = $_POST['v_id'];

$sql = "SELECT * from vehicle where v_id = {$v_id}";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
      	
$arr["v_id"] = $row["v_id"];       	
$arr["make"] = $row["make"];
$arr["mod"] = $row["model"];
$arr["prefix"] = $row["prefix"];
$arr["year"] = $row["year"];
$arr["length"] = $row["length"];
$arr["width"] = $row["width"];
$arr["height"] = $row["height"];
$arr["m3"] = $row["m3"];
$arr["kgs"] = $row["kgs"];

}

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>