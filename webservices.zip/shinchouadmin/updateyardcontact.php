<?php
header("Content-Type: application/json");

require('db_con.php');

$y_id = $_POST['y_id'];
$tel = $_POST['tel'];
$fax = $_POST['fax'];
$email = $_POST['email'];
$dte = $_POST['dte'];


	$sql = "update yard set email = '{$email}',tel = '{$tel}',fax = '{$fax}', statustime = '{$dte}' where y_id = {$y_id}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>