<?php
header("Content-Type: application/json");

require('db_con.php');

$field = $_POST['field'];
$cond = $_POST['cond'];
$tble = $_POST['tble'];

$sql = "SELECT COUNT({$field}) as cnt from {$tble} " . $cond;

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {      	
$arr[$i]["cnt"] = $row["cnt"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>