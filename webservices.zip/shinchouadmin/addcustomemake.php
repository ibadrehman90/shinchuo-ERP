<?php
header("Content-Type: application/json");
require('db_con.php');

$country = $_POST['country'];
$makelist = $_POST['makelist'];
$otherlist = $_POST['otherlist'];

$sql = "SELECT * from custommake where country = '{$country}'";

$result = $conn->query($sql);

$cid = false;

 while($row = $result->fetch_assoc()) {	
	
	$cid = true;		   
 }
 
 if($cid == false)
 {

	$sql = "insert into custommake(country, makelist, otherlist) values('{$country}','{$makelist}','{$otherlist}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 
		
 }
 else
 {
	$sql = "update custommake set makelist = '{$makelist}', otherlist = '{$otherlist}' where country = '{$country}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}
 }

$conn->close();  
	
echo json_encode($response);
	 
	
?>