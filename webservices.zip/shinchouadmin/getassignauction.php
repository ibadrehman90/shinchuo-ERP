<?php
header("Content-Type: application/json");

require('db_con.php');

$sql = "SELECT * from assignauction order by a_id DESC";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["a_id"] = $row["a_id"];       	
$arr[$i]["b_email"] = $row["b_email"];
$arr[$i]["day"] = $row["day"];
$arr[$i]["auction"] = $row["auction"];
$arr[$i]["fromdate"] = $row["fromdate"];
$arr[$i]["status"] = $row["status"];
$arr[$i]["statustime"] = $row["statustime"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>