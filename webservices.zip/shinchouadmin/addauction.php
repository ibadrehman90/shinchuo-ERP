<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$aname = $_POST['aname'];
$pos = $_POST['pos'];
$tel = $_POST['tel'];
$cname = $_POST['cname'];
$fax = $_POST['fax'];
$email = $_POST['email'];
$dte = $_POST['dte'];

	$sql = "insert into auction(aname, pos, tel, fax, cname, email, statustime) values('{$aname}','{$pos}','{$tel}','{$fax}','{$cname}','{$email}','{$dte}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

}

$conn->close();  

echo json_encode($response);
?>