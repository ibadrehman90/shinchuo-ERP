<?php
header("Content-Type: application/json");

$orderid = $_POST["orderid"];
$email = $_POST["email"];
$remarks = $_POST["remarks"];

if ($remarks == 'undefined')
$remarks = '';

$sfr = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
  
  <title>Email Format</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  
 <style>
 
 a{
 color:white; 
 }
 
 a:hover
 {
 color:white;
 cursor:pointer;
 }
 
 a:focus
 {
 color:white;
 }
 
 </style>
  
 </head>
<body style="margin: 0; padding: 0;background: #ccc;">


<div style="margin-top:75px;"></div>

<h3 style="color:#ed3338; font-weight:bold;margin-left:10px;">Transport Order</h3>

<div style="width:100%;background: #fff;padding:10px;">

<p><b>You have new order.</b></p>

<p>' . $remarks .'</p>

<a href="http://admin.shinchuo-test2.com/orderreport/' . $orderid . '?out=XLS"><button style="background:#ed3338; color:white; padding:5px;border:none;">Export as XLS</button></a>&nbsp;&nbsp;
<a href="http://admin.shinchuo-test2.com/orderreport/' . $orderid . '?out=PDF""><button style="background:#000; color:white; padding:5px;border:none;">Export as PDF</button></a>

</div>


</body>
</html>';

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

$response['Status'] = '';
 	
if(mail($email,"Transport Order",$sfr, $headers))
{
$response['Status'] = 'Done';
}
else
{
$response['Status'] = 'An Error Occured. Please try again later!';
}




 	 echo json_encode($response);
	 
	
?>