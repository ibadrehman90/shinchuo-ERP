<?php
header("Content-Type: application/json");

require('db_con.php');

$prodid = $_POST['prodid'];

$sql = "SELECT * from productdetail where id = '{$prodid}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
      	
$arr["id"] = $row["id"];       	
$arr["lot"] = $row["lot"];
$arr["auction"] = $row["auction"];
$arr["auction_date"] = $row["auction_date"];
$arr["make"] = $row["make"];
$arr["model"] = $row["model"];
$arr["year"] = $row["year"];
$arr["enginecc"] = $row["enginecc"];
$arr["chassis"] = $row["chassis"];
$arr["grade"] = $row["grade"];
$arr["color"] = $row["color"];
$arr["rate"] = $row["rate"];
$arr["transmission"] = $row["transmission"];
$arr["mileage"] = $row["mileage"];
$arr["start"] = $row["start"];
$arr["images"] = $row["images"];
$arr["serial"] = $row["serial"];
$arr["avg_price"] = $row["avg_price"];

}

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>