<?php
header("Content-Type: application/json");

require('db_con.php');

$cat = $_POST['cat'];
$role = $_POST['role'];
$aucs = $_POST['aucs'];

if($role == 'admin')
{
if($cat == 'latest')
$sql = "SELECT * from bids inner join productdetail on bids.prodid = productdetail.id where auction_date >= '". date("Y-m-d") . "' AND status = 0";

else if($cat == 'archived')
$sql = "SELECT * from bids inner join productdetail on bids.prodid = productdetail.id where auction_date < '". date("Y-m-d") . "' OR status != 0";
}
else
{
if($cat == 'latest')
$sql = "SELECT * from bids inner join productdetail on bids.prodid = productdetail.id where auction_date >= '". date("Y-m-d") . "' AND status = 0" . $aucs;

else if($cat == 'archived')
/*$sql = "SELECT * from bids inner join productdetail on bids.prodid = productdetail.id where auction_date < '". date("Y-m-d") . "' OR (auction_date >= '". date("Y-m-d") . "' AND status != 0)" . $aucs;	*/

$sql = "SELECT * from bids inner join productdetail on bids.prodid = productdetail.id where (auction_date < '". date("Y-m-d") . "' OR status != 0)" . $aucs;

}

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["b_id"] = $row["b_id"]; 
$arr[$i]["prodid"] = $row["prodid"];       	
$arr[$i]["auction"] = $row["auction"];
$arr[$i]["auctiondate"] = $row["auction_date"];
$arr[$i]["lot"] = $row["lot"];
$arr[$i]["chassis"] = $row["chassis"];
$arr[$i]["make"] = $row["make"];
$arr[$i]["model"] = $row["model"];
$arr[$i]["year"] = $row["year"];
$arr[$i]["transmission"] = $row["transmission"];
$arr[$i]["start"] = $row["start"];
$arr[$i]["rate"] = $row["rate"];
$arr[$i]["estprice"] = $row["estprice"];
$arr[$i]["user_id"] = $row["user_id"];
$arr[$i]["bidmsg"] = $row["bidmsg"];
$arr[$i]["images"] = $row["images"];
$arr[$i]["status"] = $row["status"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>