<?php
header("Content-Type: application/json");

require('db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$yardname = $_POST['yardname'];
$branch = $_POST['branch'];
$streetaddress = $_POST['streetaddress'];
$billingaddress = $_POST['billaddress'];
$city = $_POST['city'];
$country = $_POST['country'];
$pos = $_POST['postalcode'];
$tel = $_POST['tel'];
$fax = $_POST['fax'];
$prefacture = $_POST['prefacture'];
$reps = $_POST['reps'];
$email = $_POST['email'];
$ports = $_POST['ports'];
$services = $_POST['services'];
$dte = $_POST['dte'];


$str_1 = "[" . $reps . "]";
$res = json_decode($str_1, true);
$prt = json_decode($ports, true);
$yser = json_decode($services, true);

$repquery = '';


$sql = "select * from yard where name = '{$yardname}'";

$result = $conn->query($sql);

$i = 0;

while($row = $result->fetch_assoc()) {
 	$i++;     	
}

if($i == 0)
{

	$sql = "insert into yard(name, branch, address, billingaddress, city, country, pos, tel, fax, prefacture, email, statustime, status) values('{$yardname}','{$branch}','{$streetaddress}','{$billingaddress}','{$city}','{$country}','{$pos}','{$tel}','{$fax}','{$prefacture}','{$email}','{$dte}',0)";

	if ($conn->query($sql) === TRUE) {
	    
	    $idd = $conn->insert_id;
	    
for($j = 0; $j < count($res); $j++)
{
    $repquery .= "insert into yardcontactpersons(repname, mob, email, yardid) values('". $res[$j]["rep"] ."','". $res[$j]["mob"] ."','". $res[$j]["remail"] ."'," . $idd . ");";
}

for($j = 0; $j < count($prt); $j++)
{
    $repquery .= "insert into yardports(portid, yardid) values(". $prt[$j].", " . $idd . ");";
}

for($j = 0; $j < count($yser); $j++)
{
    $repquery .= "insert into yardyardservices(serviceid, yardid) values(". $yser[$j]."," . $idd . ");";
}

	    
	    if ($conn->multi_query($repquery)) {
        do {
                if ($result = $conn->store_result()) {
                    while ($row = $result->fetch_row()) {
                        //printf("%s\n", $row[0]);
                    }
                    $result->free();
                }
                /* print divider */
                if ($conn->more_results()) {
                   // printf("-----------------\n");
                }
            } while ($conn->next_result());
            
            $response['Status'] = "Done";
        }
		
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}
	
}
else
{
	$response['Status'] = "Exist";
}



}

$conn->close();  

echo json_encode($response);
?>