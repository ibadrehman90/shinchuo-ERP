<?php
header("Content-Type: application/json");

require('db_con.php');

$sname = $_POST['sname'];
$cperson = $_POST['cperson'];
$tel = $_POST['tel'];
$mob = $_POST['mob'];
$fax = $_POST['fax'];
$email = $_POST['email'];
$status = $_POST['status'];

if($sname == 'undefined')
	$sname = '';

if($cperson == 'undefined')
	$cperson = '';

if($tel == 'undefined')
	$tel = '';

if($mob == 'undefined')
	$mob = '';

if($fax == 'undefined')
	$fax = '';

if($email == 'undefined')
	$email = '';

if($status == 'undefined')
	$status = '';

$sql = "SELECT * from bookingagent where sname LIKE '%{$sname}%' && cperson LIKE '%{$cperson}%' && phone LIKE '%{$tel}%' && mobile LIKE '%{$mob}%' && fax LIKE '%{$fax}%' && email LIKE '%{$email}%' && status LIKE '%{$status}%'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["s_id"] = $row["s_id"];       	
$arr[$i]["sname"] = $row["sname"];
$arr[$i]["cperson"] = $row["cperson"];
$arr[$i]["tel"] = $row["phone"];
$arr[$i]["mob"] = $row["mobile"];
$arr[$i]["fax"] = $row["fax"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["statustime"] = $row["statustime"];
$arr[$i]["status"] = $row["status"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>