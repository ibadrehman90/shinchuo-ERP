<?php
header("Content-Type: application/json");

require('./../../db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$bno = $_POST['bno'];
$freight = $_POST['freight'];
$unit = $_POST['unit'];
$curr = $_POST['curr'];
$range = $_POST['range'];


	$sql = "insert into booking_freight(freight, unit, currency, bookingid, ranges) VALUES('{$freight}', '{$unit}', '{$curr}', '{$bno}', '{$range}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

}

$conn->close();  

echo json_encode($response);
?>