<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$sql = "SELECT y_id, name, serviceid, yard.status as approval FROM `yard` left join yardyardservices on yard.y_id = yardyardservices.yardid order by y_id";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["y_id"] = $row["y_id"];       	
$arr[$i]["yardname"] = $row["name"];
$arr[$i]["serviceid"] = $row["serviceid"];
$arr[$i]["approval"] = $row["approval"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>