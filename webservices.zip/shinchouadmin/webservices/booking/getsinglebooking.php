<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$bno = $_POST['bno'];

$sql = "SELECT b_no, dco, (select name from yard where y_id = yardid) as yard,(select name from yard where y_id = drainageyard) as drainageyard, (select sname from bookingagent where s_id = bagencyid) as bagency, (select port from ports where port_id = originport) as origin, (select port from ports where port_id = destport) as dest, etd, eta, bookingno, confirmedon, shipmentype, contype, cargotype, conditiontype, yardopen, address, yco, dft, dmft, qty, penaltyfree, reciepturl, (select iname from inspection where ins_id = insid) as inspection, (select vesselname from vessel where ys_id = vesselid) as vessel, (select voyage from voyages where v_id = voyageid) as voyage FROM `booking` inner join shipscheduleroutes on booking.routeid = shipscheduleroutes.r_id inner join shipmentschedule on shipmentschedule.ss_id = shipscheduleroutes.scheduleid where b_no = '{$bno}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["b_no"] = $row["b_no"];       	
$arr[$i]["dco"] = $row["dco"];
$arr[$i]["yard"] = $row["yard"];
$arr[$i]["bagency"] = $row["bagency"];
$arr[$i]["origin"] = $row["origin"];
$arr[$i]["dest"] = $row["dest"];
$arr[$i]["etd"] = $row["etd"];
$arr[$i]["eta"] = $row["eta"];
$arr[$i]["bookingno"] = $row["bookingno"];
$arr[$i]["confirmedon"] = $row["confirmedon"];
$arr[$i]["shipmentype"] = $row["shipmentype"];
$arr[$i]["qty"] = $row["qty"];
$arr[$i]["vessel"] = $row["vessel"];
$arr[$i]["voyage"] = $row["voyage"];

$arr[$i]["contype"] = $row["contype"];
$arr[$i]["cargotype"] = $row["cargotype"];
$arr[$i]["conditiontype"] = $row["conditiontype"];
$arr[$i]["yardopen"] = $row["yardopen"];
$arr[$i]["address"] = $row["address"];
$arr[$i]["yco"] = $row["yco"];
$arr[$i]["dft"] = $row["dft"];
$arr[$i]["dmft"] = $row["dmft"];
$arr[$i]["penaltyfree"] = $row["penaltyfree"];
$arr[$i]["reciepturl"] = $row["reciepturl"];
$arr[$i]["inspection"] = $row["inspection"];
$arr[$i]["drainageyard"] = $row["drainageyard"];


	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>