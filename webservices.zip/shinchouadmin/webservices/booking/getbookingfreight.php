<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$bno = $_POST['bno'];

$sql = "SELECT * from booking_freight where bookingid = '{$bno}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["bf_id"] = $row["bf_id"];       	
$arr[$i]["freight"] = $row["freight"];
$arr[$i]["unit"] = $row["unit"];
$arr[$i]["currency"] = $row["currency"];
$arr[$i]["ranges"] = $row["ranges"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>