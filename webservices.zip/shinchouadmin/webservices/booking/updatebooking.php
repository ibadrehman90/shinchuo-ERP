<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$cat = $_POST['cat'];
$val = $_POST['val'];
$bno = $_POST['bno'];



	$sql = "update booking set {$cat} = '{$val}' where b_no = '{$bno}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>