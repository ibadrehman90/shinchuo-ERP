<?php
header("Content-Type: application/json");

require('./../../db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$yard = $_POST['yard'];
$drainageyard = $_POST['drainageyard'];
$bagency = $_POST['bagency'];
$route = $_POST['route'];
$bno = $_POST['bno'];
$confirmedon = $_POST['confirmedon'];
$shipmenttype = $_POST['shipmentype'];
$containertype = $_POST['containertype'];
$conditiontype = $_POST['conditiontype'];
$cargotype = $_POST['cargotype'];
$qty = $_POST['qty'];
$yardopen = $_POST['yardopen'];
$address = $_POST['address'];
$dco = $_POST['dco'];
$yco = $_POST['yco'];
$dft = $_POST['dft'];
$dmft = $_POST['dmft'];
$insid = $_POST['insid'];
$penaltyfree = $_POST['pfree'];
$freightcont = $_POST['freightcon'];
$paymentcont = $_POST['paymentcon'];
$reciepturl = $_POST['reciepturl'];


$str_1 = "[" . $freightcont . "]";
$res = json_decode($str_1, true);

$str_2 = "[" . $paymentcont . "]";
$res2 = json_decode($str_2, true);

$repquery = '';


$sql = "select * from booking where bookingno = '{$bno}'";

$result = $conn->query($sql);

$i = 0;

while($row = $result->fetch_assoc()) {
 	$i++;     	
}

if($i == 0)
{

	$sql = "insert into booking(yardid, drainageyard, bagencyid, routeid, bookingno, confirmedon, shipmentype, contype, cargotype, conditiontype, qty, yardopen, address, dco, yco, dft, dmft, insid, penaltyfree, reciepturl) values('{$yard}','{$drainageyard}','{$bagency}','{$route}','{$bno}','{$confirmedon}','{$shipmenttype}','{$containertype}','{$cargotype}','{$conditiontype}','{$qty}','{$yardopen}','{$address}','{$dco}','{$yco}','{$dft}','{$dmft}','{$insid}','{$penaltyfree}','{$reciepturl}')";

	if ($conn->query($sql) === TRUE) {
	    
	    $idd = $conn->insert_id;
	    
for($j = 0; $j < count($res); $j++)
{
    $repquery .= "insert into booking_freight(freight, unit, currency, bookingid, ranges) values('". $res[$j]["freight"] ."','". $res[$j]["unit"] ."','". $res[$j]["currency"] ."'," . $idd . ",'". $res[$j]["range"] ."');";
}

for($j = 0; $j < count($res2); $j++)
{
    $repquery .= "insert into booking_payment(chargeid, selectopt, bookingid) values('". $res2[$j]["charge"] ."','". $res2[$j]["selectopt"] ."'," . $idd . ");";
}

	    
	    if ($conn->multi_query($repquery)) {
        do {
                if ($result = $conn->store_result()) {
                    while ($row = $result->fetch_row()) {
                        //printf("%s\n", $row[0]);
                    }
                    $result->free();
                }
                /* print divider */
                if ($conn->more_results()) {
                   // printf("-----------------\n");
                }
            } while ($conn->next_result());
            
            $response['Status'] = "Done";
        }
        else {
		$response['Status'] = "Error: " . $conn->error . $str_1;
	    }
		
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}
	
}
else
{
	$response['Status'] = "Exist";
}



}

$conn->close();  

echo json_encode($response);
?>