<?php

header("Content-Type: application/json");

require('./../../db_con.php');

$target_dir = "reciepts/";

$username = $_POST['userid'];

$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$err = '';
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$err.= $target_file;

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    $err .= "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        
       $err = "Done";
        
    } else {
        $err .= "Sorry, there was an error uploading your file.";
    }
}

echo json_encode($err);

?>