<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$yardname = $_POST['yard'];
$vesselname = $_POST['vessel'];
$bookingno = $_POST['bookingno'];

if($yardname == 'undefined')
	$yardname = '';

if($vesselname == 'undefined')
	$vesselname = '';

if($bookingno == 'undefined')
	$bookingno = '';

$sql = "SELECT * from (SELECT b_no, dco, (select name from yard where y_id = yardid) as yard, (select sname from bookingagent where s_id = bagencyid) as bagency, (select port from ports where port_id = originport) as origin, (select port from ports where port_id = destport) as dest, etd, eta, bookingno, confirmedon, shipmentype, qty, (select vesselname from vessel where ys_id = vesselid) as vessel, (select voyage from voyages where v_id = voyageid) as voyage FROM `booking` inner join shipscheduleroutes on booking.routeid = shipscheduleroutes.r_id inner join shipmentschedule on shipmentschedule.ss_id = shipscheduleroutes.scheduleid) as t1 where yard LIKE '%{$yardname}%' AND vessel LIKE '%{$vesselname}%' AND bookingno LIKE '%{$bookingno}%'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["b_no"] = $row["b_no"];       	
$arr[$i]["dco"] = $row["dco"];
$arr[$i]["yard"] = $row["yard"];
$arr[$i]["bagency"] = $row["bagency"];
$arr[$i]["origin"] = $row["origin"];
$arr[$i]["dest"] = $row["dest"];
$arr[$i]["etd"] = $row["etd"];
$arr[$i]["eta"] = $row["eta"];
$arr[$i]["bookingno"] = $row["bookingno"];
$arr[$i]["confirmedon"] = $row["confirmedon"];
$arr[$i]["shipmentype"] = $row["shipmentype"];
$arr[$i]["qty"] = $row["qty"];
$arr[$i]["vessel"] = $row["vessel"];
$arr[$i]["voyage"] = $row["voyage"];
	   
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>