<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$bno = $_POST['bno'];
$shiptype = $_POST['shiptype'];

$sql = '';

if($shiptype == 'CONTAINER')
{
$sql = "SELECT * FROM `booking_payment` inner join containercharge on booking_payment.chargeid = containercharge.c_id where bookingid = '{$bno}'";
}
else if($shiptype == 'RORO')
{
$sql = "SELECT * FROM `booking_payment` inner join rorocharge on booking_payment.chargeid = rorocharge.c_id where bookingid = '{$bno}'";
}


$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["bp_id"] = $row["bp_id"];       	
$arr[$i]["chargeid"] = $row["chargeid"];
$arr[$i]["selectopt"] = $row["selectopt"];
$arr[$i]["charge"] = $row["charge"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>