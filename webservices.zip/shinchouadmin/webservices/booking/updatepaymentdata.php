<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$item = $_POST['temp'];
$bno = $_POST['bno'];

$str_2 = "[" . $item . "]";
$res2 = json_decode($str_2, true);

$repquery = '';

$response['Status'] = '';


for($j = 0; $j < count($res2); $j++)
{
    $repquery .= "update booking_payment set selectopt = '". $res2[$j]["selectopt"] ."' where bp_id = " . $res2[$j]["ident"] . ";";
}

	    
	    if ($conn->multi_query($repquery)) {
        do {
                if ($result = $conn->store_result()) {
                    while ($row = $result->fetch_row()) {
                        //printf("%s\n", $row[0]);
                    }
                    $result->free();
                }
               
                if ($conn->more_results()) {
                   // printf("-----------------\n");
                }
            } while ($conn->next_result());
            
            $response['Status'] = "Done";
        }
        else {
		$response['Status'] = "Error: " . $conn->error. $repquery;
	    }


$conn->close();  
	
echo json_encode($response);
	 
	
?>