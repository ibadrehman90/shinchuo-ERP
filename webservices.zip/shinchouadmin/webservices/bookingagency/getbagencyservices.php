<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$y_id = $_POST['y_id'];

$sql = "SELECT * from bagencyservices inner join bookingservices on bagencyservices.serviceid = bookingservices.ys_id where agencyid = {$y_id}";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
      	
$arr[$i]["bs_id"] = $row["bs_id"];       	
$arr[$i]["servicename"] = $row["servicename"];
$arr[$i]["approval"] = $row["approval"];
$arr[$i]["generatedby"] = $row["generatedby"];
$i++;
}

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>