<?php
header("Content-Type: application/json");

require('./../../db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$yardid = $_POST['yardid'];
$reps = $_POST['val'];


$str_1 = "[" . $reps . "]";
$res = json_decode($str_1, true);
$prt = json_decode($ports, true);
$yser = json_decode($services, true);

$repquery = "delete from bagencycontactperson where agencyid = '{$yardid}';";
	    
for($j = 0; $j < count($res); $j++)
{
    $repquery .= "insert into bagencycontactperson(repname, mob, email, agencyid) values('". $res[$j]["rep"] ."','". $res[$j]["mob"] ."','". $res[$j]["remail"] ."'," . $yardid . ");";
}


	    if ($conn->multi_query($repquery)) {
        do {
                if ($result = $conn->store_result()) {
                    while ($row = $result->fetch_row()) {
                        //printf("%s\n", $row[0]);
                    }
                    $result->free();
                }
                /* print divider */
                if ($conn->more_results()) {
                   // printf("-----------------\n");
                }
            } while ($conn->next_result());
            
            $response['Status'] = "Done";
        }
		
	else {
		$response['Status'] = "Error: " . $conn->error;
	}

}

$conn->close();  

echo json_encode($response);
?>