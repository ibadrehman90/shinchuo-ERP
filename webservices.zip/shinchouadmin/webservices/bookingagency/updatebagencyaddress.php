<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$y_id = $_POST['y_id'];
$address = $_POST['address'];
$dte = $_POST['dte'];


	$sql = "update bookingagent set address = '{$address}', statustime = '{$dte}' where s_id = {$y_id}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>