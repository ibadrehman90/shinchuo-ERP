<?php
header("Content-Type: application/json");

require('./../../db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$bname = $_POST['bname'];
$branch = $_POST['branch'];
$address = $_POST['address'];
$tel = $_POST['tel'];
$fax = $_POST['fax'];
$reps = $_POST['reps'];
$email = $_POST['email'];
$services = $_POST['services'];
$dte = $_POST['dte'];


$str_1 = "[" . $reps . "]";
$res = json_decode($str_1, true);
$yser = json_decode($services, true);

$repquery = '';


$sql = "select * from bookingagent where sname = '{$bname}'";

$result = $conn->query($sql);

$i = 0;

while($row = $result->fetch_assoc()) {
 	$i++;     	
}

if($i == 0)
{

	$sql = "insert into bookingagent(sname, branch, address, tel, fax, email, statustime, status) values('{$bname}','{$branch}','{$address}','{$tel}','{$fax}','{$email}','{$dte}',0)";

	if ($conn->query($sql) === TRUE) {
	    
	    $idd = $conn->insert_id;
	    
for($j = 0; $j < count($res); $j++)
{
    $repquery .= "insert into bagencycontactperson(repname, mob, email, agencyid) values('". $res[$j]["rep"] ."','". $res[$j]["mob"] ."','". $res[$j]["remail"] ."'," . $idd . ");";
}

for($j = 0; $j < count($yser); $j++)
{
    $repquery .= "insert into bagencyservices(serviceid, agencyid) values(". $yser[$j]."," . $idd . ");";
}

	    
	    if ($conn->multi_query($repquery)) {
        do {
                if ($result = $conn->store_result()) {
                    while ($row = $result->fetch_row()) {
                        //printf("%s\n", $row[0]);
                    }
                    $result->free();
                }
                /* print divider */
                if ($conn->more_results()) {
                   // printf("-----------------\n");
                }
            } while ($conn->next_result());
            
            $response['Status'] = "Done";
        }
		
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}
	
}
else
{
	$response['Status'] = "Exist";
}



}

$conn->close();  

echo json_encode($response);
?>