<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$name = $_POST['name'];
$branch = $_POST['branch'];
$email = $_POST['email'];

if($name == 'undefined')
	$name = '';

if($branch == 'undefined')
	$branch = '';

if($email == 'undefined')
	$email = '';

$sql = "SELECT * from bookingagent where sname LIKE '%{$name}%' AND branch LIKE '%{$branch}%' AND email LIKE '%{$email}%'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["s_id"] = $row["s_id"];       	
$arr[$i]["name"] = $row["sname"];
$arr[$i]["address"] = $row["address"];
$arr[$i]["branch"] = $row["branch"];
$arr[$i]["tel"] = $row["tel"];
$arr[$i]["fax"] = $row["fax"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["statustime"] = $row["statustime"];
$arr[$i]["status"] = $row["status"];
	   
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>