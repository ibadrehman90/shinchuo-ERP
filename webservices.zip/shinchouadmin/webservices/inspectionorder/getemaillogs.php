<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$insoid = $_POST['insoid'];

$sql = "select * from insorderemails where insoid = '{$insoid}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["e_id"] = $row["e_id"];       	
$arr[$i]["emails"] = $row["emails"];
$arr[$i]["remarks"] = $row["remarks"];
$arr[$i]["updatedon"] = $row["updatedon"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>