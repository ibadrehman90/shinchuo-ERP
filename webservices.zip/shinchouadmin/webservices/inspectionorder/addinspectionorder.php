<?php
header("Content-Type: application/json");

require('./../../db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$vehicles = $_POST['vehiclelist'];
$servicename = $_POST['servicename'];
$inspection = $_POST['inspection'];
$requestedon = $_POST['requestedon'];
$emaillist = $_POST['emaillist'];
$remarks = $_POST['remarks'];
$generatedby = $_POST['generatedby'];
$vehiclejson = $_POST['vehiclejson'];
$reqinspection = $_POST['reqinspection'];
$dte = date("Y/m/d");


$str_2 = "[" . $vehiclejson . "]";
$res2 = json_decode($str_2, true);

$repquery = '';

$emtext = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
  
  <title>Email Format</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  
 <style>
 h3{
 margin:5px;
 padding:10px;
 font-family: Calibri;
 }
 
 span
 {
	font-size:14px;
	color:#333;
 }
 </style>
  
 </head>
<body style="margin: 0; padding: 0;">

<table align="center" cellpadding="10" cellspacing="0" style="border-collapse: collapse;">

			
<tr style="border-bottom:1px solid #999;text-align:center">
	<td colspan="2"><h3>Inspection Order</h3></td>
</tr>
</table>

<table cellpadding="10" cellspacing="0" style="border-collapse: collapse;">
<tr>
	<td><b>Required Inspection</b></td>
	<td>'. $reqinspection .'</td>
</tr>
<tr>
	<td><b>Service Name</b></td>
	<td>'. $servicename .'</td>
</tr>
<tr>
	<td><b>Requested On</b></td>
	<td>'. $requestedon .'</td>
</tr>
<tr>
	<td><b>Remarks</b></td>
	<td>'. $remarks .'</td>
</tr>
</table>



<table align="center" border="1" cellpadding="10" cellspacing="0">
<tr>
	<th>S.No.</th>
	<th>Chassis</th>
	<th>Make</th>
	<th>Model</th>
	<th>Year</th>
	<th>Yard</th>
</tr>';

for($j = 0; $j < count($res2); $j++)
{
    $emtext .= '<tr><td>';
    $emtext .= $j + 1;
    $emtext .= '</td><td>';
    $emtext .= $res2[$j]["chassis"];
    $emtext .= '</td><td>';
    $emtext .= $res2[$j]["make"];
    $emtext .= '</td><td>';
    $emtext .= $res2[$j]["model"];
    $emtext .= '</td><td>';
    $emtext .= $res2[$j]["year"];
    $emtext .= '</td><td>';
    $emtext .= $res2[$j]["yardname"];
    $emtext .= '</td></tr>';
}

$emtext .= '</table>
</body>
</html>';

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";



	$sql = "insert into inspectionorder(servicename,reqon,insid, generatedby,vehicleid,status) values('{$servicename}','{$requestedon}','{$inspection}','{$generatedby}','{$vehicles}',0)";

	if ($conn->query($sql) === TRUE) {
	    
	     $idd = $conn->insert_id;
            
            
            if(mail($emaillist,"Inspection Order",$emtext, $headers) == TRUE)
            {
                $sql = "insert into insorderemails(emails, remarks, updatedon, insoid) values('{$emaillist}', '{$remarks}','{$dte}',". $idd .")";

            	if ($conn->query($sql) === TRUE) {
                
                    $response['Status'] = "Done";
                }
                else {
            		$response['Status'] = "Error: " . $conn->error;
            	}
            }
            else
            {
                	$response['Status'] = "Email not Sent!";
            }
		
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}
	



}

$conn->close();  

echo json_encode($response);
?>