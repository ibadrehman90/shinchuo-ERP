<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$sql = "select prefix, year, (select iname from inspection where ins_id = insid) as inspection, generatedby, servicename, reqon, make, model, yardname, inso_id, inspectionorder.status as stat from inspectionorder inner join (select * from (select o_id,p_id,auction, adate, dai, serial, s_code, plateserial,lot, make, model, year, prefix, client, currentloc, (select port from userauth where username = client) as port, (select country from userauth where username = client) as country, (select name from yard where yard.y_id = orders.y_id) as yardname from orders inner join orderdetail on orderdetail.ord_id = orders.orderno inner join purchasedlist on orderdetail.p_id = purchasedlist.s_id where orders.ostatus = 1) as t1 where o_id IN (SELECT MAX(o_id) from (select o_id,p_id,auction, adate, dai, serial, s_code, plateserial,lot, make, model, year, prefix, client, currentloc, (select port from userauth where username = client) as port, (select country from userauth where username = client) as country, (select name from yard where yard.y_id = orders.y_id) as yardname from orders inner join orderdetail on orderdetail.ord_id = orders.orderno inner join purchasedlist on orderdetail.p_id = purchasedlist.s_id where orders.ostatus = 1) as t2 GROUP by p_id)) as p1 on inspectionorder.vehicleid = p1.p_id";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["inso_id"] = $row["inso_id"];       	
$arr[$i]["prefix"] = $row["prefix"];
$arr[$i]["make"] = $row["make"];
$arr[$i]["model"] = $row["model"];
$arr[$i]["year"] = $row["year"];
$arr[$i]["reqon"] = $row["reqon"];
$arr[$i]["yardname"] = $row["yardname"];
$arr[$i]["servicename"] = $row["servicename"];
$arr[$i]["generatedby"] = $row["generatedby"];
$arr[$i]["status"] = $row["stat"];
$arr[$i]["inspection"] = $row["inspection"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>