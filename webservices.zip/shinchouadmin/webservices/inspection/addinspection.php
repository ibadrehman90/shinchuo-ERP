<?php
header("Content-Type: application/json");

require('./../../db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$name = $_POST['chargename'];
$username = $_POST['username'];

$sql = "select * from inspection where iname = '{$name}'";

$result = $conn->query($sql);

$i = 0;

while($row = $result->fetch_assoc()) {
 	$i++;     	
}

if($i == 0)
{

	$sql = "insert into inspection(iname, generatedby) values('{$name}','{$username}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

}
else
{
	$response['Status'] = "Exist";
}

}

$conn->close();  

echo json_encode($response);
?>