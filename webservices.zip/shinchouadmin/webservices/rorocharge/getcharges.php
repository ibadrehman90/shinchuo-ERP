<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$sql = "SELECT * from rorocharge";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["c_id"] = $row["c_id"];       	
$arr[$i]["charge"] = $row["charge"];
$arr[$i]["generatedby"] = $row["generatedby"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>