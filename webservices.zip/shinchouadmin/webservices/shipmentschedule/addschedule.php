<?php
header("Content-Type: application/json");

require('./../../db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$vesselid = $_POST['vesselid'];
$voyageid = $_POST['voyageid'];
$reps = $_POST['routes'];
$username = $_POST['username'];


$str_1 = "[" . $reps . "]";
$res = json_decode($str_1, true);

$repquery = '';


	$sql = "insert into shipmentschedule(vesselid, voyageid, generatedby) values('{$vesselid}','{$voyageid}','{$username}')";

	if ($conn->query($sql) === TRUE) {
	    
	    $idd = $conn->insert_id;
	    
for($j = 0; $j < count($res); $j++)
{
    $repquery .= "insert into shipscheduleroutes(originport, etd, destport, eta, scheduleid) values('". $res[$j]["origin"] ."','". $res[$j]["etd"] ."','". $res[$j]["dest"] ."','". $res[$j]["eta"] ."'," . $idd . ");";
}

	    if ($conn->multi_query($repquery)) {
        do {
                if ($result = $conn->store_result()) {
                    while ($row = $result->fetch_row()) {
                        //printf("%s\n", $row[0]);
                    }
                    $result->free();
                }
                /* print divider */
                if ($conn->more_results()) {
                   // printf("-----------------\n");
                }
            } while ($conn->next_result());
            
            $response['Status'] = "Done";
        }
		
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

}

$conn->close();  

echo json_encode($response);
?>