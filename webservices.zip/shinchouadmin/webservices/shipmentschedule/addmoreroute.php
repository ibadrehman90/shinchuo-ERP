<?php
header("Content-Type: application/json");

require('./../../db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$origin = $_POST['originport'];
$ssid = $_POST['ssid'];
$etd = $_POST['etd'];
$destport = $_POST['destport'];
$eta = $_POST['eta'];


	$sql = "insert into shipscheduleroutes(originport, etd, destport, eta, scheduleid) values('{$origin}','{$etd}','{$destport}','{$eta}','{$ssid}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

}

$conn->close();  

echo json_encode($response);
?>