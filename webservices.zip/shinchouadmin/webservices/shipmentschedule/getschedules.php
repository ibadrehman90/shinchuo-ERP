<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$sql = "select r_id, ss_id, vesselname, voyage, (select port from ports where ports.port_id = originport) as origin, etd, (select port from ports where ports.port_id = destport) as dest,eta, shipmentschedule.generatedby, (select COUNT(*) from shipscheduleroutes where scheduleid = ss_id) as maxrow from shipscheduleroutes inner join shipmentschedule on shipscheduleroutes.scheduleid = shipmentschedule.ss_id inner join vessel on shipmentschedule.vesselid = vessel.ys_id inner join voyages on voyages.v_id = shipmentschedule.voyageid";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["sid"] = $row["ss_id"];
$arr[$i]["r_id"] = $row["r_id"];
$arr[$i]["vessel"] = $row["vesselname"];
$arr[$i]["voyage"] = $row["voyage"];
$arr[$i]["originport"] = $row["origin"];
$arr[$i]["destport"] = $row["dest"];
$arr[$i]["etd"] = $row["etd"];
$arr[$i]["eta"] = $row["eta"];
$arr[$i]["maxrow"] = $row["maxrow"];
$arr[$i]["generatedby"] = $row["generatedby"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>