<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$sql = "SELECT * from vessel where approval = 0";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["ys_id"] = $row["ys_id"];       	
$arr[$i]["vesselname"] = $row["vesselname"];
$arr[$i]["generatedby"] = $row["generatedby"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>