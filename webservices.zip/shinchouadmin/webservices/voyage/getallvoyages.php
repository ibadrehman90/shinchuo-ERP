<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$sql = "SELECT * from voyages inner join vessel on voyages.vesselid = vessel.ys_id";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["v_id"] = $row["v_id"];       	
$arr[$i]["voyage"] = $row["voyage"];
$arr[$i]["vesselid"] = $row["vesselid"];
$arr[$i]["vessel"] = $row["vesselname"];
$arr[$i]["generatedby"] = $row["generatedby"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>