<?php
header("Content-Type: application/json");

require('./../../db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$name = $_POST['voyagename'];
$vessel = $_POST['vesselid'];
$username = $_POST['username'];

$sql = "select * from voyages where voyage = '{$name}' AND vesselid = '{$vessel}'";

$result = $conn->query($sql);

$i = 0;

while($row = $result->fetch_assoc()) {
 	$i++;     	
}

if($i == 0)
{

	$sql = "insert into voyages(voyage, vesselid, generatedby) values('{$name}', '{$vessel}','{$username}')";

	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}

}
else
{
	$response['Status'] = "Exist";
}

}

$conn->close();  

echo json_encode($response);
?>