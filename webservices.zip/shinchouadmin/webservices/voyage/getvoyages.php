<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$vesselid = $_POST["vessel"];

$sql = "SELECT * from voyages where vesselid = '{$vesselid}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["v_id"] = $row["v_id"];       	
$arr[$i]["voyage"] = $row["voyage"];
$arr[$i]["generatedby"] = $row["generatedby"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>