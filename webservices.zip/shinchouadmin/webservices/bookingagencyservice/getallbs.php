<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$sql = "SELECT * from bookingservices order by approval";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["ys_id"] = $row["ys_id"];       	
$arr[$i]["servicename"] = $row["servicename"];
$arr[$i]["approval"] = $row["approval"];
$arr[$i]["generatedby"] = $row["generatedby"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>