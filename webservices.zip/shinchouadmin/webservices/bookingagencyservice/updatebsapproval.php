<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$portid = $_POST['ysid'];
$status = $_POST['status'];


	$sql = "update bookingservices set approval = '{$status}' where ys_id = '{$portid}'";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>