<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$scid = $_POST['scid'];
$address = $_POST['address'];


	$sql = "update shipmentconsignee set caddress = '{$address}' where sc_id = {$scid}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>