<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$scid = $_POST['scid'];
$tel = $_POST['tel'];
$fax = $_POST['fax'];
$email = $_POST['email'];


	$sql = "update shipmentconsignee set email = '{$email}',tel = '{$tel}',fax = '{$fax}' where sc_id = {$scid}";
	
	if ($conn->query($sql) === TRUE) {
		$response['Status'] = "Done";
	} else {
		$response['Status'] = "Error: " . $conn->error;
	} 


$conn->close();  
	
echo json_encode($response);
	 
	
?>