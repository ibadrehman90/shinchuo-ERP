<?php
header("Content-Type: application/json");

require('./../../db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$cusage = $_POST['cusage'];
$name = $_POST['name'];
$address = $_POST['address'];
$tel = $_POST['tel'];
$fax = $_POST['fax'];
$email = $_POST['email'];
$dest = $_POST['dest'];
$clients = $_POST['clients'];
$vehicles = $_POST['vehicles'];
$generatedby = $_POST['generatedby'];


if($dest != '')
{
$str_1 = "[" . $dest . "]";
$res = json_decode($str_1, true);
}

if($clients != '' && $cusage != 'Single Use')
{
$str_2 = "[" . $clients . "]";
$res2 = json_decode($str_2, true);
}

if($vehicles != '')
{
$str_3 = "[" . $vehicles . "]";
$res3 = json_decode($str_3, true);
}

$repquery = '';

$sql = "select * from shipmentconsignee where cname = '{$name}'";

$result = $conn->query($sql);

$i = 0;

while($row = $result->fetch_assoc()) {
 	$i++;     	
}

if($i == 0)
{

	$sql = "insert into shipmentconsignee(cname, caddress, tel, fax, email, cusage, generatedby) values('{$name}','{$address}','{$tel}','{$fax}','{$email}','{$cusage}','{$generatedby}')";

	if ($conn->query($sql) === TRUE) {
	    
	    $idd = $conn->insert_id;
	    
	    
if($dest != '')
{
    for($j = 0; $j < count($res); $j++)
    {
        $repquery .= "insert into consigneedestination(portid, scid) values('". $res[$j]["dest"] ."'," . $idd . ");";
    }
}

if($clients != '' && $cusage != 'Single Use')
{
    for($j = 0; $j < count($res2); $j++)
    {
        $repquery .= "insert into consigneeclients(clid, scid) values('". $res2[$j]["client"] ."'," . $idd . ");";
    }
}
else if($clients != '' && $cusage == 'Single Use')
{
     $repquery .= "insert into consigneeclients(clid, scid) values('". $clients ."'," . $idd . ");";
}

if($vehicles != '')
{
    for($j = 0; $j < count($res3); $j++)
    {
        $repquery .= "insert into consigneevehicles(pid, scid) values('". $res3[$j]["vehicle"] ."'," . $idd . ");update purchasedlist set consigneestatus = 1 where s_id = '". $res3[$j]["vehicle"] ."';";
    }
}


	    
	    if ($conn->multi_query($repquery)) {
        do {
                if ($result = $conn->store_result()) {
                    while ($row = $result->fetch_row()) {
                        //printf("%s\n", $row[0]);
                    }
                    $result->free();
                }
                /* print divider */
                if ($conn->more_results()) {
                   // printf("-----------------\n");
                }
            } while ($conn->next_result());
            
            $response['Status'] = "Done";
        }
        else {
		$response['Status'] = "Error: " . $conn->error . $str_1;
	    }
		
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}
	
}
else
{
	$response['Status'] = "Exist";
}



}

$conn->close();  

echo json_encode($response);
?>