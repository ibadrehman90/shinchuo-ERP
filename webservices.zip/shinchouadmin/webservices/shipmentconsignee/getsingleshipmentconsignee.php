<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$csid = $_POST['csid'];

$sql = "select * from shipmentconsignee where sc_id = '{$csid}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["sc_id"] = $row["sc_id"];
$arr[$i]["cname"] = $row["cname"]; 
$arr[$i]["caddress"] = $row["caddress"];       	
$arr[$i]["tel"] = $row["tel"];
$arr[$i]["fax"] = $row["fax"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["cusage"] = $row["cusage"];
$arr[$i]["generatedby"] = $row["generatedby"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>