<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$csid = $_POST['csid'];

$sql = "select * from consigneeclients where scid = '{$csid}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["c_id"] = $row["c_id"]; 
$arr[$i]["clid"] = $row["clid"]; 
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>