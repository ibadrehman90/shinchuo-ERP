<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$csid = $_POST['csid'];

$sql = "SELECT * FROM consigneedestination inner join ports on consigneedestination.portid = ports.port_id where scid = '{$csid}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["d_id"] = $row["d_id"];
$arr[$i]["scid"] = $row["scid"];
$arr[$i]["portid"] = $row["portid"];
$arr[$i]["port"] = $row["port"];
$arr[$i]["country"] = $row["country"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>