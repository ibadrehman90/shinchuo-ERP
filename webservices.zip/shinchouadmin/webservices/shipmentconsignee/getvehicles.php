<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$csid = $_POST['csid'];

$sql = "SELECT * FROM consigneevehicles inner join purchasedlist on consigneevehicles.pid = purchasedlist.s_id where scid = '{$csid}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["v_id"] = $row["v_id"];
$arr[$i]["scid"] = $row["scid"];
$arr[$i]["s_id"] = $row["s_id"];
$arr[$i]["make"] = $row["make"];
$arr[$i]["model"] = $row["model"];
$arr[$i]["year"] = $row["year"];
$arr[$i]["prefix"] = $row["prefix"];
$arr[$i]["serial"] = $row["serial"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>