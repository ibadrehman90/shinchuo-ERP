<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$plancode = $_POST['plancode'];

$sql = "select * from loadingplanvehicles inner join purchasedlist on loadingplanvehicles.purid = purchasedlist.s_id where codeplan = '{$plancode}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["p_id"] = $row["s_id"];
$arr[$i]["auction"] = $row["auction"];
$arr[$i]["adate"] = $row["adate"];
$arr[$i]["dai"] = $row["dai"];
$arr[$i]["serial"] = $row["serial"];
$arr[$i]["s_code"] = $row["s_code"];
$arr[$i]["plateserial"] = $row["plateserial"];
$arr[$i]["lot"] = $row["lot"];
$arr[$i]["make"] = $row["make"]; 
$arr[$i]["model"] = $row["model"];       	
$arr[$i]["year"] = $row["year"];
$arr[$i]["prefix"] = $row["prefix"];
$arr[$i]["client"] = $row["client"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>