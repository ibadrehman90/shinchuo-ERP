<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$yardname = $_POST['yardname'];

$sql = "select * from (select * from (select o_id,p_id,auction, adate, dai, serial, s_code, plateserial,lot, make, model, year, prefix, client, currentloc, (select port from userauth where username = client) as port, (select country from userauth where username = client) as country, (select name from yard where yard.y_id = orders.y_id) as yardname from orders inner join orderdetail on orderdetail.ord_id = orders.orderno inner join purchasedlist on orderdetail.p_id = purchasedlist.s_id where orders.ostatus = 1) as t1 where o_id IN (SELECT MAX(o_id) from (select o_id,p_id,auction, adate, dai, serial, s_code, plateserial,lot, make, model, year, prefix, client, currentloc, (select port from userauth where username = client) as port, (select country from userauth where username = client) as country, (select name from yard where yard.y_id = orders.y_id) as yardname from orders inner join orderdetail on orderdetail.ord_id = orders.orderno inner join purchasedlist on orderdetail.p_id = purchasedlist.s_id where orders.ostatus = 1) as t2 GROUP by p_id)) as tt5 where yardname = '{$yardname}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["p_id"] = $row["p_id"];
$arr[$i]["auction"] = $row["auction"];
$arr[$i]["adate"] = $row["adate"];
$arr[$i]["dai"] = $row["dai"];
$arr[$i]["serial"] = $row["serial"];
$arr[$i]["s_code"] = $row["s_code"];
$arr[$i]["plateserial"] = $row["plateserial"];
$arr[$i]["lot"] = $row["lot"];
$arr[$i]["make"] = $row["make"]; 
$arr[$i]["model"] = $row["model"];       	
$arr[$i]["year"] = $row["year"];
$arr[$i]["prefix"] = $row["prefix"];
$arr[$i]["client"] = $row["client"];
$arr[$i]["port"] = $row["port"];
$arr[$i]["country"] = $row["country"];
$arr[$i]["yardname"] = $row["yardname"];
$arr[$i]["currentloc"] = $row["currentloc"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>