<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$plancode = $_POST['plancode'];

$sql = "select * from loadingplan inner join yard on loadingplan.yardid = yard.y_id where plancode = '{$plancode}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["plancode"] = $row["plancode"];
$arr[$i]["yard"] = $row["name"];
$arr[$i]["contype"] = $row["contype"];
$arr[$i]["generatedby"] = $row["generatedby"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>