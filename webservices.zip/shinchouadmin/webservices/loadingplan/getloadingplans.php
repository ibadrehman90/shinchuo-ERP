<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$yardname = $_POST['yardname'];

$sql = "select plancode, (select name from yard where y_id = yardid) as yardname, generatedby, contype, (select count(*) as cnt from loadingplanvehicles where codeplan = plancode) as units, (select GROUP_CONCAT(prefix) as vehicles from loadingplanvehicles inner join purchasedlist on loadingplanvehicles.purid = purchasedlist.s_id where codeplan = plancode) as frames from loadingplan where yardid = '{$yardname}'";

if($yardname == '')
{

$sql = "select plancode, (select name from yard where y_id = yardid) as yardname, generatedby, contype, (select count(*) as cnt from loadingplanvehicles where codeplan = plancode) as units, (select GROUP_CONCAT(prefix) as vehicles from loadingplanvehicles inner join purchasedlist on loadingplanvehicles.purid = purchasedlist.s_id where codeplan = plancode) as frames from loadingplan";

}



$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["plancode"] = $row["plancode"];
$arr[$i]["units"] = $row["units"];
$arr[$i]["frames"] = $row["frames"];
$arr[$i]["contype"] = $row["contype"];
$arr[$i]["yardname"] = $row["yardname"];
$arr[$i]["generatedby"] = $row["generatedby"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>