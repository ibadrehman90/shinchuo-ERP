<?php
header("Content-Type: application/json");

require('./../../db_con.php');
$response['Status'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

$yard = $_POST['yardname'];
$contype = $_POST['contype'];
$username = $_POST['username'];
$vehicles = $_POST['vehiclelist'];
$plancode = $_POST['plancode'];


$str_1 = "[" . $vehicles . "]";
$res = json_decode($str_1, true);

$repquery = '';


	$sql = "insert into loadingplan(plancode, contype, yardid, generatedby) values('{$plancode}','{$contype}','{$yard}','{$username}')";

	if ($conn->query($sql) === TRUE) {
	    
	    
for($j = 0; $j < count($res); $j++)
{
    $repquery .= "insert into loadingplanvehicles(codeplan, purid) values('". $plancode ."','". $res[$j]["pid"] ."');";
}

	    
	    if ($conn->multi_query($repquery)) {
        do {
                if ($result = $conn->store_result()) {
                    while ($row = $result->fetch_row()) {
                        //printf("%s\n", $row[0]);
                    }
                    $result->free();
                }
                /* print divider */
                if ($conn->more_results()) {
                   // printf("-----------------\n");
                }
            } while ($conn->next_result());
            
            $response['Status'] = "Done";
        }
        else {
		$response['Status'] = "Error: " . $conn->error . $str_1;
	    }
		
	} else {
		$response['Status'] = "Error: " . $conn->error;
	}
	



}

$conn->close();  

echo json_encode($response);
?>