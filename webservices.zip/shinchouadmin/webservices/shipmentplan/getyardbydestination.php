<?php
header("Content-Type: application/json");

require('./../../db_con.php');

$dest = $_POST['destport'];

$sql = "select DISTINCT(yardname), y_id as yardid from (select * from (select o_id,p_id,auction, adate, dai, serial, orders.y_id, s_code, plateserial,lot, make, model, year, prefix, client, currentloc, (select port from userauth where username = client) as port, (select country from userauth where username = client) as country, (select name from yard where yard.y_id = orders.y_id) as yardname from orders inner join orderdetail on orderdetail.ord_id = orders.orderno inner join purchasedlist on orderdetail.p_id = purchasedlist.s_id where orders.ostatus = 1) as t1 where o_id IN (SELECT MAX(o_id) from (select o_id,p_id,auction, adate, dai, serial, s_code, plateserial,lot, make, model, year, prefix, client, currentloc, (select port from userauth where username = client) as port, (select country from userauth where username = client) as country, (select name from yard where yard.y_id = orders.y_id) as yardname from orders inner join orderdetail on orderdetail.ord_id = orders.orderno inner join purchasedlist on orderdetail.p_id = purchasedlist.s_id where orders.ostatus = 1) as t2 GROUP by p_id)) as tabyard where port = '{$dest}'";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["yardid"] = $row["yardid"];
$arr[$i]["yardname"] = $row["yardname"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>