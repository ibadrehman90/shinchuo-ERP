<?php
header("Content-Type: application/json");

require('db_con.php');

$y_id = $_POST['y_id'];

$sql = "SELECT *, (SELECT GROUP_CONCAT(portid) from yardports where yardid = y_id) as portsid, (SELECT GROUP_CONCAT(serviceid) from yardyardservices where yardid = y_id) as yardservicesid from yard where y_id = {$y_id}";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
      	
$arr[$i]["y_id"] = $row["y_id"];       	
$arr[$i]["name"] = $row["name"];
$arr[$i]["address"] = $row["address"];
$arr[$i]["billingaddress"] = $row["billingaddress"];
$arr[$i]["branch"] = $row["branch"];
$arr[$i]["city"] = $row["city"];
$arr[$i]["country"] = $row["country"];
$arr[$i]["pos"] = $row["pos"];
$arr[$i]["tel"] = $row["tel"];
$arr[$i]["fax"] = $row["fax"];
$arr[$i]["prefacture"] = $row["prefacture"];
$arr[$i]["email"] = $row["email"];
$arr[$i]["statustime"] = $row["statustime"];
$arr[$i]["status"] = $row["status"];
$arr[$i]["portsid"] = $row["portsid"];
$arr[$i]["yardservicesid"] = $row["yardservicesid"];

}

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>