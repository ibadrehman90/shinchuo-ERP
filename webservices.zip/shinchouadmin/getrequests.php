<?php
header("Content-Type: application/json");

require('db_con.php');

$sql = "SELECT * from lccrequests order by sno DESC";

$str  = '';

$result = $conn->query($sql);

$arr = array();
$i = 0;

 while($row = $result->fetch_assoc()) {
$arr[$i]["sno"] = $row["sno"];       	
$arr[$i]["client"] = $row["client"];
$arr[$i]["requestby"] = $row["requestby"];
$arr[$i]["agentfee"] = $row["agentfee"];
$arr[$i]["exchange"] = $row["exchange"];
$arr[$i]["freight"] = $row["frieght"];
$arr[$i]["statustime"] = $row["statustime"];
$arr[$i]["adminstatus"] = $row["adminstatus"];
$arr[$i]["clientstatus"] = $row["clientstatus"];
	   
	   $i++;
    }

$conn->close();	
 	
$response['Status'] = $arr;

 	 echo json_encode($response);
	 
	
?>